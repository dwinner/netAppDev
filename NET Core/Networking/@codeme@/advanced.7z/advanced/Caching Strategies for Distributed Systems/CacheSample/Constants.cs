﻿namespace CacheSample
{
    public class Constants
    {
        public static readonly string DATA_CLIENT = "DATA_CLIENT";
    }
}
﻿namespace CustomProtocolDemo
{
    public enum RockStatus
    {
        SUCCESS,
        PARTIAL,
        FAILURE
    }
}
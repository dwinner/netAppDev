﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SQLiteSetup.cs" company="Flush Arcade Pty Ltd.">
//   Copyright (c) 2015 Flush Arcade Pty Ltd. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.IO;
using FileStorage.Portable.DataAccess.Storage;
using SQLite.Net.Interop;

namespace FileStorage.iOS.DataAccess
{
   /// <summary>
   ///    The SQLite setup object.
   /// </summary>
   public class SQLiteSetup : ISQLiteSetup
   {
      public SQLiteSetup(ISQLitePlatform platform)
      {
         DatabasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "filestorage.db3");
         Platform = platform;
      }

      public string DatabasePath { get; set; }

      public ISQLitePlatform Platform { get; set; }
   }
}
﻿namespace PointOfViewApp.Utils
{
   internal static class IntentKeys
   {
      internal const string PoiDetailKey = nameof(PoiDetailKey);

      internal const string DeleteDialogTag = nameof(DeleteDialogTag);
   }
}
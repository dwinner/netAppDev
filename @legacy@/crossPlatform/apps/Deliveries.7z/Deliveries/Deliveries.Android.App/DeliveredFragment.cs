﻿using Android.OS;
using Android.Support.V4.App;
using Deliveries.Shared;

namespace Deliveries.Android.App
{
   public class DeliveredFragment : ListFragment
   {
      public override async void OnCreate(Bundle savedInstanceState)
      {
         base.OnCreate(savedInstanceState);

         // Create your fragment here
         var delivered = await Delivery.GetDeliveredAsync();
         ListAdapter = new DeliveryAdapter(Activity, delivered);
      }
   }
}
﻿using Android.OS;
using Android.Support.V4.App;
using Android.Views;
using AppRes = Deliveries.Android.App.Resource;

namespace Deliveries.Android.App
{
   public class ProfileFragment : Fragment
   {
      public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) =>
         inflater.Inflate(Resource.Layout.profile, container, false);
   }
}
﻿using Android.OS;
using Android.Support.V4.App;
using Deliveries.Shared;

namespace Deliveries.Android.App
{
   public class DeliveriesFragment : ListFragment
   {
      public override async void OnCreate(Bundle savedInstanceState)
      {
         base.OnCreate(savedInstanceState);

         // Create your fragment here
         var deliveries = await Delivery.GetDeliveriesAsync();
         ListAdapter = new DeliveryAdapter(Activity, deliveries);
      }
   }
}
﻿using System;
using Android.App;
using Android.Gms.Maps;
using Android.Gms.Maps.Model;
using Android.Locations;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Widget;
using Deliveries.Shared;
using AppRes = Deliveries.Android.App.Resource;

namespace Deliveries.Android.App
{
   [Activity(Label = "NewDeliveryActivity")]
   public class NewDeliveryActivity : AppCompatActivity, IOnMapReadyCallback, ILocationListener
   {
      private double latitude, longitude;
      private LocationManager locationManager;
      private MapFragment mapFragment, destinationMapFragment;
      private EditText packageNameEditText;
      private Button saveButton;
      private GoogleMap _map;

      public void OnLocationChanged(Location location)
      {
         latitude = location.Latitude;
         longitude = location.Longitude;
         mapFragment.GetMapAsync(this);
         destinationMapFragment.GetMapAsync(this);
      }

      public void OnProviderDisabled(string provider)
      {
      }

      public void OnProviderEnabled(string provider)
      {
      }

      public void OnStatusChanged(string provider, [GeneratedEnum] Availability status, Bundle extras)
      {
      }

      public void OnMapReady(GoogleMap googleMap)
      {
         _map = googleMap;

         var marker = new MarkerOptions();
         marker.SetPosition(new LatLng(latitude, longitude));
         marker.SetTitle("Your location");
         googleMap.AddMarker(marker);

         googleMap.MoveCamera(CameraUpdateFactory.NewLatLngZoom(new LatLng(latitude, longitude), 10));
      }

      protected override void OnCreate(Bundle savedInstanceState)
      {
         base.OnCreate(savedInstanceState);

         // Create your application here
         SetContentView(AppRes.Layout.new_delivery);

         saveButton = FindViewById<Button>(AppRes.Id.saveButton);
         packageNameEditText = FindViewById<EditText>(AppRes.Id.packageNameEditText);

         mapFragment = FragmentManager.FindFragmentById<MapFragment>(AppRes.Id.mapFragment);
         destinationMapFragment = FragmentManager.FindFragmentById<MapFragment>(AppRes.Id.destinationMapFragment);

         saveButton.Click += SaveButton_Click;
      }

      protected override void OnResume()
      {
         base.OnResume();

         locationManager = GetSystemService(LocationService) as LocationManager;
         var provider = LocationManager.GpsProvider;
         if (locationManager.IsProviderEnabled(provider))
         {
            locationManager.RequestLocationUpdates(provider, 5000, 1, this);
         }

         var location = locationManager.GetLastKnownLocation(LocationManager.NetworkProvider);
         latitude = location.Latitude;
         longitude = location.Longitude;
         mapFragment.GetMapAsync(this);
         destinationMapFragment.GetMapAsync(this);
      }

      protected override void OnPause()
      {
         base.OnPause();
         locationManager.RemoveUpdates(this);
      }

      private async void SaveButton_Click(object sender, EventArgs e)
      {
         var destination = _map.CameraPosition.Target;
         
         var delivery = new Delivery
         {
            Name = packageNameEditText.Text,
            Status = 0,
            OriginLatitude = latitude,
            OriginLongitude = longitude,
            DestinationLatitude = destination.Latitude,
            DestinationLongitude = destination.Longitude
         };

         await Delivery.InsertDeliveryAsync(delivery);
      }
   }
}
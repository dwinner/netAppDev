﻿using System;
using Android.App;
using Android.OS;
using Android.Widget;
using Deliveries.Shared;
using AppRes = Deliveries.Android.App.Resource;

namespace DeliveriesApp.Droid
{
   [Activity(Label = "RegisterActivity")]
   public class RegisterActivity : Activity
   {
      private EditText emailEditText, passwordEditText, confirmPasswordEditText;
      private Button registerButton;

      protected override void OnCreate(Bundle savedInstanceState)
      {
         base.OnCreate(savedInstanceState);

         // Create your application here
         SetContentView(AppRes.Layout.register);

         emailEditText = FindViewById<EditText>(AppRes.Id.registerEmailEditText);
         passwordEditText = FindViewById<EditText>(AppRes.Id.registerPasswordEditText);
         confirmPasswordEditText = FindViewById<EditText>(AppRes.Id.confirmPasswordEditText);
         registerButton = FindViewById<Button>(AppRes.Id.registerUserButton);

         registerButton.Click += RegisterButton_Click;

         var email = Intent.GetStringExtra("email");
         emailEditText.Text = email;
      }

      private async void RegisterButton_Click(object sender, EventArgs e)
      {
         var result = await User.RegisterAsync(emailEditText.Text, passwordEditText.Text, confirmPasswordEditText.Text);

         if (result)
         {
            Toast.MakeText(this, "Success", ToastLength.Long).Show();
         }
         else
         {
            Toast.MakeText(this, "Try again", ToastLength.Long).Show();
         }
      }
   }
}
﻿using System;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Support.V7.App;
using Android.Widget;
using Deliveries.Shared;
using DeliveriesApp.Droid;

namespace Deliveries.Android.App
{
   [Activity(Label = "DeliveriesApp.Android", MainLauncher = true, Icon = "@mipmap/icon")]
   public class MainActivity : AppCompatActivity
   {
      private EditText emailEditText, passwordEditText;
      private Button signinButton, registerButton;

      protected override void OnCreate(Bundle bundle)
      {
         base.OnCreate(bundle);


         // Set our view from the "main" layout resource
         SetContentView(Resource.Layout.activity_main);

         emailEditText = FindViewById<EditText>(Resource.Id.emailEditText);
         passwordEditText = FindViewById<EditText>(Resource.Id.passwordEditText);
         signinButton = FindViewById<Button>(Resource.Id.signinButton);
         registerButton = FindViewById<Button>(Resource.Id.registerButton);

         signinButton.Click += SigninButton_Click;
         registerButton.Click += RegisterButton_Click;
      }

      private void RegisterButton_Click(object sender, EventArgs e)
      {
         var intent = new Intent(this, typeof(RegisterActivity));
         intent.PutExtra("email", emailEditText.Text);
         StartActivity(intent);
      }

      private async void SigninButton_Click(object sender, EventArgs e)
      {
         var email = emailEditText.Text;
         var password = passwordEditText.Text;

         var result = await User.LoginAsync(email, password);

         if (result)
         {
            Toast.MakeText(this, "Welcome", ToastLength.Long).Show();
            var intent = new Intent(this, typeof(TabsActivity));
            StartActivity(intent);
            Finish();
         }
         else
         {
            Toast.MakeText(this, "Try again later", ToastLength.Long).Show();
         }
      }
   }
}
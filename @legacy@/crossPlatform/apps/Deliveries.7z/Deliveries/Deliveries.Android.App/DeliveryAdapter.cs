﻿using System.Collections.Generic;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Deliveries.Shared;
using Java.Lang;
using AppRes = Deliveries.Android.App.Resource;

namespace Deliveries.Android.App
{
   internal class DeliveryAdapter : BaseAdapter
   {
      private readonly Context context;
      private readonly List<Delivery> deliveries;

      public DeliveryAdapter(Context context, List<Delivery> deliveries)
      {
         this.context = context;
         this.deliveries = deliveries;
      }

      //Fill in count here, currently 0
      public override int Count => deliveries.Count;

      public override Object GetItem(int position) => position;

      public override long GetItemId(int position) => position;

      public override View GetView(int position, View convertView, ViewGroup parent)
      {
         var view = convertView;
         DeliveryAdapterViewHolder holder = null;

         if (view != null)
         {
            holder = view.Tag as DeliveryAdapterViewHolder;
         }

         if (holder == null)
         {
            holder = new DeliveryAdapterViewHolder();
            var inflater = context.GetSystemService(Context.LayoutInflaterService).JavaCast<LayoutInflater>();
            //replace with your item and your holder items
            //comment back in
            view = inflater.Inflate(Resource.Layout.delivery_cell, parent, false);
            holder.Name = view.FindViewById<TextView>(Resource.Id.deliveryNameTextView);
            holder.Status = view.FindViewById<TextView>(Resource.Id.deliveryStatisTextView);
            view.Tag = holder;
         }


         //fill in your items
         var delivery = deliveries[position];
         holder.Name.Text = delivery.Name;
         switch (delivery.Status)
         {
            case 0:
               holder.Status.Text = "waiting for delivery person";
               break;
            case 1:
               holder.Status.Text = "out for delivery";
               break;
            case 2:
               holder.Status.Text = "delivered";
               break;
         }

         return view;
      }
   }

   internal class DeliveryAdapterViewHolder : Object
   {
      //Your adapter views to re-use
      public TextView Name { get; set; }
      public TextView Status { get; set; }
   }
}
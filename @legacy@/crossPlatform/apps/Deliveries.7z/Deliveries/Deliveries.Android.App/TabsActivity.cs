﻿using Android.App;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V4.App;
using Android.Support.V7.Widget;
using DeliveriesApp.Droid;
using AppRes = Deliveries.Android.App.Resource;
using Fragment = Android.Support.V4.App.Fragment;

namespace Deliveries.Android.App
{
   [Activity(Label = "TabsActivity")]
   public class TabsActivity : FragmentActivity
   {
      private TabLayout tabLayout;
      private Toolbar tabsToolbar;

      protected override void OnCreate(Bundle savedInstanceState)
      {
         base.OnCreate(savedInstanceState);

         // Create your application here
         SetContentView(Resource.Layout.tabs);

         tabsToolbar = FindViewById<Toolbar>(Resource.Id.tabsToolbar);
         tabLayout = FindViewById<TabLayout>(Resource.Id.mainTabLayout);
         tabLayout.TabSelected += TabLayout_TabSelected;

         tabsToolbar.InflateMenu(Resource.Menu.tabs_menu);
         tabsToolbar.MenuItemClick += TabsToolbar_MenuItemClick;

         FragmentNavigate(new DeliveriesFragment());
      }

      private void TabsToolbar_MenuItemClick(object sender, Toolbar.MenuItemClickEventArgs e)
      {
         if (e.Item.ItemId == Resource.Id.action_add)
         {
            StartActivity(typeof(NewDeliveryActivity));
         }
      }

      private void TabLayout_TabSelected(object sender, TabLayout.TabSelectedEventArgs e)
      {
         switch (e.Tab.Position)
         {
            case 0:
               FragmentNavigate(new DeliveriesFragment());
               break;
            case 1:
               FragmentNavigate(new DeliveredFragment());
               break;
            case 2:
               FragmentNavigate(new ProfileFragment());
               break;
         }
      }

      private void FragmentNavigate(Fragment fragment)
      {
         var transaction = SupportFragmentManager.BeginTransaction();
         transaction.Replace(Resource.Id.contentFrame, fragment);
         transaction.Commit();
      }
   }
}
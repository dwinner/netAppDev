﻿using System.Linq;
using System.Threading.Tasks;

namespace Deliveries.Shared
{
   public class User
   {
      public string Id { get; set; }

      public string Email { get; set; }

      public string Password { get; set; }

      public static async Task<bool> LoginAsync(string email, string password)
      {
         bool result;

         if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
         {
            result = false;
         }
         else
         {
            var user = (await AzureHelper.MobileService.GetTable<User>().Where(u => u.Email == email)
                  .ToListAsync()
                  .ConfigureAwait(false))
               .FirstOrDefault();

            result = user?.Password == password;
         }

         return result;
      }

      public static async Task<bool> RegisterAsync(string email, string password, string confirmPassword)
      {
         var result = false;

         if (!string.IsNullOrEmpty(password) && password == confirmPassword)
         {
            var user = new User
            {
               Email = email,
               Password = password
            };

            await AzureHelper.InsertAsync(user).ConfigureAwait(true);

            result = true;
         }

         return result;
      }
   }
}
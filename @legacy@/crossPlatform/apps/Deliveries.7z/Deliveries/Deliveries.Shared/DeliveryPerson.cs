﻿using System.Linq;
using System.Threading.Tasks;

namespace Deliveries.Shared
{
   public class DeliveryPerson
   {
      public string Id { get; set; }

      public string Email { get; set; }

      public string Password { get; set; }

      public static async Task<string> LoginAsync(string email, string password)
      {
         string userId;

         if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
         {
            userId = string.Empty;
         }
         else
         {
            var user = (await AzureHelper.MobileService.GetTable<DeliveryPerson>().Where(u => u.Email == email)
                  .ToListAsync()
                  .ConfigureAwait(false))
               .FirstOrDefault();

            userId = user?.Password == password ? user.Id : string.Empty;
         }

         return userId;
      }

      public static async Task<bool> RegisterAsync(string email, string password, string confirmPassword)
      {
         var result = false;

         if (!string.IsNullOrEmpty(password) && password == confirmPassword)
         {
            var user = new DeliveryPerson
            {
               Email = email,
               Password = password
            };

            await AzureHelper.InsertAsync(user).ConfigureAwait(false);

            result = true;
         }

         return result;
      }

      public static async Task<DeliveryPerson> GetDeliveryPersonAsync(string id)
      {
         var person = (await AzureHelper.MobileService.GetTable<DeliveryPerson>().Where(d => d.Id == id)
               .ToListAsync()
               .ConfigureAwait(false))
            .FirstOrDefault();

         return person;
      }
   }
}
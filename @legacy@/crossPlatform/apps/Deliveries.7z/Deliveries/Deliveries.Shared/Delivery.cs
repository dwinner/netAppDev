﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Deliveries.Shared
{
   public class Delivery
   {
      public string Id { get; set; }

      public string Name { get; set; }

      public double OriginLatitude { get; set; }

      public double OriginLongitude { get; set; }

      public double DestinationLatitude { get; set; }

      public double DestinationLongitude { get; set; }

      /// <summary>
      ///    0 = waiting delivery person
      ///    1 = being delivered
      ///    2 = delivered
      /// </summary>
      public int Status { get; set; }

      public string DeliveryPersonId { get; set; }

      public static async Task<bool> MarkAsPickerUpAsync(Delivery delivery, string deliveryPersonId)
      {
         try
         {
            delivery.Status = 1;
            delivery.DeliveryPersonId = deliveryPersonId;
            await AzureHelper.MobileService.GetTable<Delivery>().UpdateAsync(delivery)
               .ConfigureAwait(false);

            return true;
         }
         catch
         {
            return false;
         }
      }

      public static async Task<bool> MarkAsDeliveredAsync(Delivery delivery)
      {
         try
         {
            delivery.Status = 2;
            await AzureHelper.MobileService.GetTable<Delivery>().UpdateAsync(delivery)
               .ConfigureAwait(false);

            return true;
         }
         catch
         {
            return false;
         }
      }

      public static async Task<bool> MarkAsPickerUpAsync(string deliveryId, string deliveryPersonId)
      {
         try
         {
            var delivery =
               (await AzureHelper.MobileService.GetTable<Delivery>()
                  .Where(d => d.Id == deliveryId)
                  .ToListAsync()
                  .ConfigureAwait(false))
               .FirstOrDefault();
            if (delivery != null)
            {
               delivery.Status = 1;
               delivery.DeliveryPersonId = deliveryPersonId;
               await AzureHelper.MobileService.GetTable<Delivery>().UpdateAsync(delivery)
                  .ConfigureAwait(false);

               return true;
            }

            return false;
         }
         catch
         {
            return false;
         }
      }

      public static async Task<bool> MarkAsDeliveredAsync(string deliveryId)
      {
         try
         {
            var delivery =
               (await AzureHelper.MobileService.GetTable<Delivery>()
                  .Where(d => d.Id == deliveryId)
                  .ToListAsync()
                  .ConfigureAwait(false))
               .FirstOrDefault();
            if (delivery != null)
            {
               delivery.Status = 2;
               await AzureHelper.MobileService.GetTable<Delivery>().UpdateAsync(delivery).ConfigureAwait(false);
               return true;
            }

            return false;
         }
         catch
         {
            return false;
         }
      }

      public static async Task<List<Delivery>> GetDeliveriesAsync()
      {
         var deliveries = await AzureHelper.MobileService.GetTable<Delivery>()
            .Where(d => d.Status != 2)
            .ToListAsync()
            .ConfigureAwait(false);
         return deliveries;
      }

      public static async Task<List<Delivery>> GetDeliveredAsync()
      {
         var deliveries = await AzureHelper.MobileService.GetTable<Delivery>()
            .Where(d => d.Status == 2)
            .ToListAsync()
            .ConfigureAwait(false);

         return deliveries;
      }

      public static async Task<List<Delivery>> GetDeliveredAsync(string userId)
      {
         var deliveries = await AzureHelper.MobileService.GetTable<Delivery>()
            .Where(d => d.Status == 2 && d.DeliveryPersonId == userId)
            .ToListAsync()
            .ConfigureAwait(false);

         return deliveries;
      }

      public static async Task<List<Delivery>> GetBeingDeliveredAsync(string id)
      {
         var deliveries = await AzureHelper.MobileService.GetTable<Delivery>()
            .Where(d => d.Status == 1 && d.DeliveryPersonId == id)
            .ToListAsync()
            .ConfigureAwait(false);

         return deliveries;
      }

      public static async Task<List<Delivery>> GetWaitingAsync()
      {
         var deliveries = await AzureHelper.MobileService.GetTable<Delivery>()
            .Where(d => d.Status == 0)
            .ToListAsync()
            .ConfigureAwait(false);

         return deliveries;
      }

      public static Task<bool> InsertDeliveryAsync(Delivery delivery) =>
         AzureHelper.InsertAsync(delivery);

      public override string ToString() => $"{Name} - {Status}";
   }
}
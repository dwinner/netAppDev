﻿using System.Threading.Tasks;
using Microsoft.WindowsAzure.MobileServices;

namespace Deliveries.Shared
{
   public class AzureHelper
   {
      public static readonly MobileServiceClient MobileService =
         new MobileServiceClient("http://xamarindeliveriesapp.azurewebsites.net");

      public static async Task<bool> InsertAsync<T>(T objectToInsert)
      {
         try
         {
            await MobileService.GetTable<T>().InsertAsync(objectToInsert).ConfigureAwait(false);
            return true;
         }
         catch
         {
            return false;
         }
      }
   }
}
﻿using UIKit;

namespace Deliveries.iOS.App
{
   public class Application
   {
      private static void Main(string[] args)
      {
         UIApplication.Main(args, null, nameof(AppDelegate));
      }
   }
}
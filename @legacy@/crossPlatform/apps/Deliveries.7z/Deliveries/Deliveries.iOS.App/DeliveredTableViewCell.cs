﻿using System;
using UIKit;

namespace DeliveriesApp.iOS
{
   public partial class DeliveredTableViewCell : UITableViewCell
   {
      public DeliveredTableViewCell(IntPtr handle) : base(handle)
      {
      }
   }
}
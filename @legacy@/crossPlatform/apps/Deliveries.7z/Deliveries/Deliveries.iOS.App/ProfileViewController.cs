﻿using System;
using UIKit;

namespace DeliveriesApp.iOS
{
   public partial class ProfileViewController : UIViewController
   {
      public ProfileViewController(IntPtr handle) : base(handle)
      {
      }
   }
}
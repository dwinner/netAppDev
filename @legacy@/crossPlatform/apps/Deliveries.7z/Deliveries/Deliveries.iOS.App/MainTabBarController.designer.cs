﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//

using Foundation;

namespace Deliveries.iOS.App
{
    [Register ("MainTabBarController")]
    partial class MainTabBarController
    {
        void ReleaseDesignerOutlets ()
        {
        }
    }
}
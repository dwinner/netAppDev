﻿using System;
using UIKit;

namespace DeliveriesApp.iOS
{
   public partial class DeliveryTableViewCell : UITableViewCell
   {
      public DeliveryTableViewCell(IntPtr handle) : base(handle)
      {
      }
   }
}
using MvvmCross.Platform.Plugins;

namespace Countr.Core.Tests.Bootstrap
{
    public class MessengerPluginBootstrap
        : MvxPluginBootstrapAction<MvvmCross.Plugins.Messenger.PluginLoader>
    {
    }
}
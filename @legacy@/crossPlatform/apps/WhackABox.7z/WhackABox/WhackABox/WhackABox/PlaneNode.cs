﻿using Urho;

namespace WhackABox
{
    public class PlaneNode : Node
    {
        public string PlaneId { get; set; }
        public float ExtentX { get; set; }
        public float ExtentZ { get; set; }
    }
}
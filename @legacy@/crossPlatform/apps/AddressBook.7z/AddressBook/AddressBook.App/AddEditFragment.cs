﻿using System;
using Android.Content;
using Android.Database;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Text;
using Android.Views;
using Android.Views.InputMethods;
using static AppDevUnited.AddressBook.App.Data.DatabaseDescription.Contact;
using FragmentV4 = Android.Support.V4.App.Fragment;
using LoaderManagerV4 = Android.Support.V4.App.LoaderManager;
using CursorLoaderV4 = Android.Support.V4.Content.CursorLoader;
using LoaderV4 = Android.Support.V4.Content.Loader;
using AppLayouts = AppDevUnited.AddressBook.App.Resource.Layout;
using AppIds = AppDevUnited.AddressBook.App.Resource.Id;
using AppString = AppDevUnited.AddressBook.App.Resource.String;
using Object = Java.Lang.Object;
using Uri = Android.Net.Uri;

namespace AppDevUnited.AddressBook.App
{
   /// <summary>
   ///    Фрагмент для управления новым или изменения существующего контакта
   /// </summary>
   public class AddEditFragment : FragmentV4, LoaderManagerV4.ILoaderCallbacks
   {
      // TODO: Перенести реализацию интерфеса ILoaderCallbacks      

      private const int ContactLoader = 0; // Константа для идентификации Loader
      private bool _addingNewContact = true; // Добавление (true) или изменение
      private TextInputLayout _cityTextInputLayout;
      private Uri _contactUri; // Uri выбранного контакта
      private CoordinatorLayout _coordinatorLayout; // Для SnackBar
      private TextInputLayout _emailTextInputLayout;

      private IAddEditFragmentListener _listener; // MainActivity

      // Компоненты EditText для информации контакта
      private TextInputLayout _nameTextInputLayout;
      private TextInputLayout _phoneTextInputLayout;
      private FloatingActionButton _saveContactFab;
      private TextInputLayout _stateTextInputLayout;
      private TextInputLayout _streetTextInputLayout;
      private TextInputLayout _zipTextInputLayout;

      public LoaderV4 OnCreateLoader(int id, Bundle args)
      {
         // Создание CursorLoader на основании аргумента id; в этом
         // фрагменте только один объект Loader, и команда switch не нужна
         switch (id)
         {
            case ContactLoader:
               return new CursorLoaderV4(Activity,
                  _contactUri,
                  null,
                  null,
                  null,
                  null);

            default:
               return null;
         }
      }

      public void OnLoadFinished(LoaderV4 loader, Object data)
      {
         // Если контакт существует в базе данных, вывести его информацию
         if (data is ICursor cursor && cursor.MoveToFirst())
         {
            // Получение индекса столбца для каждого элемента данных
            var nameIndex = cursor.GetColumnIndex(ColumnName);
            var phoneIndex = cursor.GetColumnIndex(ColumnPhone);
            var emailIndex = cursor.GetColumnIndex(ColumnEmail);
            var streetIndex = cursor.GetColumnIndex(ColumnStreet);
            var cityIndex = cursor.GetColumnIndex(ColumnCity);
            var stateIndex = cursor.GetColumnIndex(ColumnState);
            var zipIndex = cursor.GetColumnIndex(ColumnZip);

            // Заполнение компонентов EditText полученными данными
            _nameTextInputLayout.EditText.Text = cursor.GetString(nameIndex);
            _phoneTextInputLayout.EditText.Text = cursor.GetString(phoneIndex);
            _emailTextInputLayout.EditText.Text = cursor.GetString(emailIndex);
            _streetTextInputLayout.EditText.Text = cursor.GetString(streetIndex);
            _cityTextInputLayout.EditText.Text = cursor.GetString(cityIndex);
            _stateTextInputLayout.EditText.Text = cursor.GetString(stateIndex);
            _zipTextInputLayout.EditText.Text = cursor.GetString(zipIndex);

            UpdateSaveFab();
         }
      }

      public void OnLoaderReset(LoaderV4 loader)
      {
      }

      public override void OnAttach(Context context)
      {
         base.OnAttach(context);
         _listener = (IAddEditFragmentListener) context;
      }

      public override void OnDetach()
      {
         base.OnDetach();
         _listener = null;
      }

      public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
      {
         base.OnCreateView(inflater, container, savedInstanceState);
         HasOptionsMenu = true; // У фрагмента есть команды меню

         // Заполнение GUI и получение ссылок на компоненты EditText
         var view = inflater.Inflate(AppLayouts.fragment_add_edit, container, false);
         _nameTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.nameTextInputLayout);
         _nameTextInputLayout.EditText.TextChanged += OnName_TextChanged;
         _phoneTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.phoneTextInputLayout);
         _emailTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.emailTextInputLayout);
         _streetTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.streetTextInputLayout);
         _cityTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.cityTextInputLayout);
         _stateTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.stateTextInputLayout);
         _zipTextInputLayout = view.FindViewById<TextInputLayout>(AppIds.zipTextInputLayout);

         // Назначение слушателя событий FloatingActionButton
         _saveContactFab = view.FindViewById<FloatingActionButton>(AppIds.saveFloatingActionButton);
         _saveContactFab.Click += OnSave_Click;
         UpdateSaveFab();

         // Используется для отображения Snackbar с короткими сообщениями
         _coordinatorLayout = Activity.FindViewById<CoordinatorLayout>(AppIds.coordinatorLayout);

         if (Arguments != null)
         {
            _addingNewContact = false;
            _contactUri = (Uri) Arguments.GetParcelable(MainActivity.ContactUri);
         }

         // При изменении существующего контакта создать Loader
#pragma warning disable 618
         if (_contactUri != null) LoaderManager.InitLoader(ContactLoader, null, this);
#pragma warning restore 618

         return view;
      }

      private void UpdateSaveFab()
      {
         var input = _nameTextInputLayout.EditText.Text.Trim();
         if (!string.IsNullOrWhiteSpace(input))
            _saveContactFab.Show();
         else
            _saveContactFab.Hide();
      }

      private void OnSave_Click(object sender, EventArgs e)
      {
         // Скрыть виртуальную клавиатуру
         ((InputMethodManager) Activity.GetSystemService(Context.InputMethodService)).HideSoftInputFromWindow(
            View.WindowToken, HideSoftInputFlags.None);
         SaveContact();
      }

      /// <summary>
      ///    Сохранение информации о контакте в базе данных
      /// </summary>
      private void SaveContact()
      {
         var contentValues = new ContentValues();
         contentValues.Put(ColumnName, _nameTextInputLayout.EditText.Text.Trim());
         contentValues.Put(ColumnPhone, _phoneTextInputLayout.EditText.Text.Trim());
         contentValues.Put(ColumnEmail, _emailTextInputLayout.EditText.Text.Trim());
         contentValues.Put(ColumnStreet, _streetTextInputLayout.EditText.Text.Trim());
         contentValues.Put(ColumnCity, _cityTextInputLayout.EditText.Text.Trim());
         contentValues.Put(ColumnState, _stateTextInputLayout.EditText.Text.Trim());
         contentValues.Put(ColumnZip, _zipTextInputLayout.EditText.Text.Trim());

         if (_addingNewContact)
         {
            // Использовать объект ContentResolver активности для вызова insert для объекта AddressBookContentProvider
            var newContactUri = Activity.ContentResolver.Insert(ContentUri, contentValues);
            if (newContactUri != null)
            {
               Snackbar.Make(_coordinatorLayout, AppString.contact_added, Snackbar.LengthLong).Show();
               _listener.OnAddEditCompleted(newContactUri); // TODO: Настроить observer/rx вместо callback-интерфейсов
            }
            else
            {
               Snackbar.Make(_coordinatorLayout, AppString.contact_not_added, Snackbar.LengthLong).Show();
            }
         }
         else
         {
            // Использовать объект ContentResolver активности для вызова update для объекта AddressBookContentProvider
            var updatedRows = Activity.ContentResolver.Update(_contactUri, contentValues, null, null);
            if (updatedRows > 0)
            {
               _listener.OnAddEditCompleted(_contactUri);
               Snackbar.Make(_coordinatorLayout, AppString.contact_updated, Snackbar.LengthLong).Show();
            }
            else
            {
               Snackbar.Make(_coordinatorLayout, AppString.contact_not_updated, Snackbar.LengthLong).Show();
            }
         }
      }

      private void OnName_TextChanged(object sender, TextChangedEventArgs e) => UpdateSaveFab();

      /// <summary>
      ///    Определяет метод обратного вызова, реализованный MainActivity
      /// </summary>
      public interface IAddEditFragmentListener
      {
         /// <summary>
         ///    Вызывается при сохранении контакта
         /// </summary>
         /// <param name="contactUri">URI-контакта</param>
         void OnAddEditCompleted(Uri contactUri);
      }
   }
}
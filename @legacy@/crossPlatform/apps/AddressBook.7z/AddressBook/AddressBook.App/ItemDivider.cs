﻿using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Support.V7.Widget;

namespace AppDevUnited.AddressBook.App
{
   public class ItemDivider : RecyclerView.ItemDecoration
   {
      private readonly Drawable _divider;

      public ItemDivider(Context context)
      {
         int[] attrs = {Android.Resource.Attribute.ListDivider};
         _divider = context.ObtainStyledAttributes(attrs).GetDrawable(0);
      }

      public override void OnDrawOver(Canvas canvas, RecyclerView parent, RecyclerView.State state)
      {
         base.OnDrawOver(canvas, parent, state);

         var left = parent.PaddingLeft;
         var right = parent.Width - parent.PaddingRight;

         for (var i = 0; i < parent.ChildCount - 1; i++)
         {
            var item = parent.GetChildAt(i);
            var top = item.Bottom + ((RecyclerView.LayoutParams) item.LayoutParameters).BottomMargin;
            var bottom = top + _divider.IntrinsicHeight;
            _divider.SetBounds(left, top, right, bottom);
            _divider.Draw(canvas);
         }
      }
   }
}
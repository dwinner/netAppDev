﻿using Android.App;
using Android.Content;
using Android.Database;
using Android.OS;
using Android.Views;
using Android.Widget;
using DialogFragmentV4 = Android.Support.V4.App.DialogFragment;
using FragmentV4 = Android.Support.V4.App.Fragment;
using LoaderManagerV4 = Android.Support.V4.App.LoaderManager;
using CursorLoaderV4 = Android.Support.V4.Content.CursorLoader;
using LoaderV4 = Android.Support.V4.Content.Loader;
using AppLayouts = AppDevUnited.AddressBook.App.Resource.Layout;
using AppIds = AppDevUnited.AddressBook.App.Resource.Id;
using AppMenus = AppDevUnited.AddressBook.App.Resource.Menu;
using AppStrings = AppDevUnited.AddressBook.App.Resource.String;
using static AppDevUnited.AddressBook.App.Data.DatabaseDescription.Contact;
using AlertDialog = Android.Support.V7.App.AlertDialog;
using Object = Java.Lang.Object;
using Uri = Android.Net.Uri;

namespace AppDevUnited.AddressBook.App
{
   public class DetailFragment : FragmentV4, LoaderManagerV4.ILoaderCallbacks
   {  // TODO: Перенести реализацию ILoaderCallbacks в другое место
      private const int ContactLoader = 0; // Идентифицирует Loader
      private const string ConfirmDeleteTag = "Confirm delete";
      private TextView _cityTextView; // Город

      private DialogFragmentV4 _confirmDelete;
      private Uri _contactUri; // Uri выбранного контакта
      private TextView _emailTextView; // Электронная почта
      private IDetailFragmentListener _listener; // MainActivity
      private TextView _nameTextView; // Имя контакта
      private TextView _phoneTextView; // Телефон
      private TextView _stateTextView; // Штат
      private TextView _streetTextView; // Улица
      private TextView _zipTextView; // Почтовый индекс

      public LoaderV4 OnCreateLoader(int id, Bundle args)
      {
         switch (id)
         {
            case ContactLoader:
               return new CursorLoaderV4(Activity,
                  _contactUri,
                  null,
                  null,
                  null,
                  null);

            default:
               return null;
         }
      }

      public void OnLoadFinished(LoaderV4 loader, Object data)
      {
         if (data is ICursor cursor && cursor.MoveToFirst())
         {
            // TODO: Avoid copy paste
            // Получение индекса столбца для каждого элемента данных
            var nameIndex = cursor.GetColumnIndex(ColumnName);
            var phoneIndex = cursor.GetColumnIndex(ColumnPhone);
            var emailIndex = cursor.GetColumnIndex(ColumnEmail);
            var streetIndex = cursor.GetColumnIndex(ColumnStreet);
            var cityIndex = cursor.GetColumnIndex(ColumnCity);
            var stateIndex = cursor.GetColumnIndex(ColumnState);
            var zipIndex = cursor.GetColumnIndex(ColumnZip);

            // Заполнение компонентов EditText полученными данными
            _nameTextView.Text = cursor.GetString(nameIndex);
            _phoneTextView.Text = cursor.GetString(phoneIndex);
            _emailTextView.Text = cursor.GetString(emailIndex);
            _streetTextView.Text = cursor.GetString(streetIndex);
            _cityTextView.Text = cursor.GetString(cityIndex);
            _stateTextView.Text = cursor.GetString(stateIndex);
            _zipTextView.Text = cursor.GetString(zipIndex);
         }
      }

      public void OnLoaderReset(LoaderV4 loader)
      {
      }

      public override void OnAttach(Context context)
      {
         base.OnAttach(context);
         _listener = (IDetailFragmentListener) context;
      }

      public override void OnDetach()
      {
         base.OnDetach();
         _listener = null;
      }

      public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
      {
         base.OnCreateView(inflater, container, savedInstanceState);
         HasOptionsMenu = true; // У фрагмента есть команды меню

         // Получение объекта Bundle с аргументами и извлечение URI
         if (Arguments != null) _contactUri = (Uri) Arguments.GetParcelable(MainActivity.ContactUri);

         _confirmDelete = new ConfirmDeleteDialog(this);

         // Заполнение макета DetailFragment
         var view = inflater.Inflate(AppLayouts.fragment_detail, container, false);
         _nameTextView = view.FindViewById<TextView>(AppIds.nameTextView);
         _phoneTextView = view.FindViewById<TextView>(AppIds.phoneTextView);
         _emailTextView = view.FindViewById<TextView>(AppIds.emailTextView);
         _streetTextView = view.FindViewById<TextView>(AppIds.streetTextView);
         _cityTextView = view.FindViewById<TextView>(AppIds.cityTextView);
         _stateTextView = view.FindViewById<TextView>(AppIds.stateTextView);
         _zipTextView = view.FindViewById<TextView>(AppIds.zipTextView);

         // Загрузка контакта
#pragma warning disable 618
         LoaderManager.InitLoader(ContactLoader, null, this);
#pragma warning restore 618

         return view;
      }

      public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
      {
         base.OnCreateOptionsMenu(menu, inflater);
         inflater.Inflate(AppMenus.fragment_details_menu, menu);
      }

      public override bool OnOptionsItemSelected(IMenuItem item)
      {
         switch (item.ItemId)
         {
            case AppIds.action_edit:
               _listener.OnEditContact(_contactUri); // Передача URI слушателю
               break;

            case AppIds.action_delete:
               DeleteContact();
               return true;
         }

         return base.OnOptionsItemSelected(item);
      }

      private void DeleteContact() => _confirmDelete.Show(FragmentManager, ConfirmDeleteTag);

      /// <summary>
      ///    Методы обратного вызова, реализованные MainActivity
      /// </summary>
      public interface IDetailFragmentListener
      {
         /// <summary>
         ///    Вызывается при удалении контакта
         /// </summary>
         void OnContactDeleted();

         /// <summary>
         ///    Вызывается при редактировании контакта
         /// </summary>
         /// <param name="contactUri">Uri-контакта</param>
         void OnEditContact(Uri contactUri);
      }

      private sealed class ConfirmDeleteDialog : DialogFragmentV4
      {
         private readonly DetailFragment _fragment;

         public ConfirmDeleteDialog(DetailFragment fragment) => _fragment = fragment;

         public override Dialog OnCreateDialog(Bundle savedInstanceState) =>
            new AlertDialog.Builder(Activity)
               .SetTitle(AppStrings.confirm_title)
               .SetMessage(AppStrings.confirm_message)
               .SetPositiveButton(AppStrings.button_delete, (sender, args) =>
               {
                  var deletedCount = _fragment.Activity.ContentResolver.Delete(_fragment._contactUri, null, null);
                  if (deletedCount > 0) _fragment._listener.OnContactDeleted();
               })
               .SetNegativeButton(AppStrings.button_cancel, (sender, args) => { })
               .Create();
      }
   }
}
﻿namespace AutolotLibrary
{
   public class NewCar
   {
      public int CarId { get; set; }
      public string Color { get; set; }
      public string Make { get; set; }
      public string PetName { get; set; }
   }
}

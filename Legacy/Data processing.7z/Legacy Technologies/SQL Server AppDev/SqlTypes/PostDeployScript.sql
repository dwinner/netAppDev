﻿-- Ручное развертывание UDT
--create assembly SqlTypes from 'D:\SENDTO\To Card Reader\SQL Server AppDev\SqlTypes\bin\Debug\SqlTypes.dll';
--create type Coordinate external name [SqlTypes].[SqlTypes.SqlCoordinate];
﻿namespace SqlTypes
{
   public enum Orientation
   {
      NorthEast,
      NorthWest,
      SouthEast,
      SouthWest
   }
}
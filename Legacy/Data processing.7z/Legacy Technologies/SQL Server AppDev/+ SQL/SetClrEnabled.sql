sp_configure [clr enabled], 1 
reconfigure 
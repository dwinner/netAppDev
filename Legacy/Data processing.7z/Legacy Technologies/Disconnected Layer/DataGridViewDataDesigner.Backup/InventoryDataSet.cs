﻿namespace DataGridViewDataDesigner {
    
    
    public partial class InventoryDataSet {
        partial class InventoryDataTable
        {
        }
    }
}

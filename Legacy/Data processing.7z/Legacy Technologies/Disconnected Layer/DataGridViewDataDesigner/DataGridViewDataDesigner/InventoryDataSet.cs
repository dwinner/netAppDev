﻿namespace DataGridViewDataDesigner {
    
    
    public partial class InventoryDataSet {
    }
}

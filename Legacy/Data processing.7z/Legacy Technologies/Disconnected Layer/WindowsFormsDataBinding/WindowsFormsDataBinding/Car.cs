﻿namespace WindowsFormsDataBinding
{
   public class Car
   {
      public int Id { get; set; }
      public string PetName { get; set; }
      public string Make { get; set; }
      public string Color { get; set; }
   }
}

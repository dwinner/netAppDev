namespace Northwind.DataContext
{
   partial class Current_Product_List
   {
   }

   partial class NorthwindDataContext
   {
   }
}

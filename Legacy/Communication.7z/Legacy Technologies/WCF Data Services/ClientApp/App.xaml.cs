﻿namespace ClientApp
{   
   public partial class App
   {
   }
}
﻿// Создание кода по умолчанию отключено для модели "D:\Programming and Development\C#, .NET\Communications\WCF Data Services\RestaurantDataServiceWeb\RestaurantModel.edmx". 
// Чтобы включить создание кода по умолчанию, замените значение свойства "Стратегия создания кода"
// конструктора на другое. Это свойство доступно в окне "Свойства", когда модель
// открыта в конструкторе.
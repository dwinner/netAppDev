﻿namespace WebRequestClient
{
   public partial class App
   {
   }
}
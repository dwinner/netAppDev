﻿namespace MemoryGame.App.Services
{
    public interface IHaptic
    {
        void ActivateHaptic();
    }
}

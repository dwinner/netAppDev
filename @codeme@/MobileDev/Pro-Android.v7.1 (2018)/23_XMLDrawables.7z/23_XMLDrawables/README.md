# Credit goes where credit is due

Bill, Chris, and Brian were responsible for this code. The sounds, though? The sounds in BeatBox/app/src/main/assets/rasslin? We got them from plagasul, at [http://www.freesound.org/people/plagasul/packs/3/](http://www.freesound.org/people/plagasul/packs/3/).

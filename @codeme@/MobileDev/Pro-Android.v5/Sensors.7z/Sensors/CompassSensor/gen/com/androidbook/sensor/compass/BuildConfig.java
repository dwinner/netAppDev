/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.sensor.compass;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
/** Automatically generated file. DO NOT MODIFY */
package com.android.sensor.virtualjax;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
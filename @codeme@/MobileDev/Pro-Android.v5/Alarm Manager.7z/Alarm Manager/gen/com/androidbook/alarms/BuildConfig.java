/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.alarms;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
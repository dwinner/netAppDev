﻿namespace TPHWithConventions
{
    public class CashPayment : Payment
    {
    }
}

﻿namespace TableSplitting
{
    public class MenuDetails
    {
        public int MenuDetailsId { get; set; }
        public string KitchenInfo { get; set; }
        public int MenusSold { get; set; }
        public Menu Menu { get; set; }
    }
}

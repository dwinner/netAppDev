﻿using Akka.Actor;

namespace Akka.Net.Succinctly.Chapter10.Actors
{
    public class EchoActor : ReceiveActor { }
}
﻿namespace Akka.Net.Succinctly.Chapter4
{
    public class Answer
    {
        public Answer(double value)
        {
            Value = value;
        }

        public double Value;
    }
}
﻿namespace Akka.Net.Succinctly.Routers
{
    public class Answer
    {
        public Answer(double value)
        {
            Value = value;
        }

        public double Value;
    }
}
﻿using NUnit.Framework;

namespace Akka.Net.Succinctly.Chapter11.Calculator
{
    [TestFixture]
    public class CalculatorActorTest : Akka.TestKit.NUnit.TestKit
    {
        [Test]
        public void SomeTest()
        {
            /* test goes here */
        }
    }
}
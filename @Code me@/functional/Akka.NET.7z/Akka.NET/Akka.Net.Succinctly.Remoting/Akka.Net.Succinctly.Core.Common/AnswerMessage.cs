﻿namespace Akka.Net.Succinctly.Core.Common
{
    public class AnswerMessage
    {
        public AnswerMessage(double value)
        {
            Value = value;
        }

        public double Value;
    }
}
namespace ShoppyExample
{
    class Store
    {
        public Position Location { get; set; }
        public string Name { get; set; }

    }
}
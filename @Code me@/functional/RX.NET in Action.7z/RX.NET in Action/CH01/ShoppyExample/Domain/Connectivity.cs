namespace ShoppyExample
{
    public enum Connectivity
    {
        Online,
        Offline
    }
}
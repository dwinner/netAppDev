﻿namespace Subjects
{
    enum NetworkConnectivity
    {
        Connected,
        Disconnected
    }
}
﻿namespace ReactingToErrors
{
    internal class WeatherSimulation
    {
    }
}
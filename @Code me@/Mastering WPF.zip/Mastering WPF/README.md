# Mastering-Windows-Presentation-Foundation-Second-Edition
Mastering Windows Presentation Foundation, Second Edition, published by Packt

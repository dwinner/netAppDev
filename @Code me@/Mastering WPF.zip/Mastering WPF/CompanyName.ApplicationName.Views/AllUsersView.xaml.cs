﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for AllUsersView.xaml
    /// </summary>
    public partial class AllUsersView : UserControl
    {
        /// <summary>
        /// Initializes a new AllUsersView object.
        /// </summary>
        public AllUsersView()
        {
            InitializeComponent();
        }
    }
}
﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for AllProductsView.xaml
    /// </summary>
    public partial class AllProductsView : UserControl
    {
        /// <summary>
        /// Initializes a new AllProductsView object.
        /// </summary>
        public AllProductsView()
        {
            InitializeComponent();
        }
    }
}
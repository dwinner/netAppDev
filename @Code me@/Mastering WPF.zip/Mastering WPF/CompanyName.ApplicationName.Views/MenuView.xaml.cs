﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for MenuView.xaml
    /// </summary>
    public partial class MenuView : UserControl
    {
        /// <summary>
        /// Initializes a new MenuView object.
        /// </summary>
        public MenuView()
        {
            InitializeComponent();
        }
    }
}
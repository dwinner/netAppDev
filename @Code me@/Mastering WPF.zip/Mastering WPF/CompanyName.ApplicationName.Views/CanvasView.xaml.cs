﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for CanvasView.xaml
    /// </summary>
    public partial class CanvasView : UserControl
    {
        /// <summary>
        /// Initializes a new CanvasView object.
        /// </summary>
        public CanvasView()
        {
            InitializeComponent();
        }
    }
}
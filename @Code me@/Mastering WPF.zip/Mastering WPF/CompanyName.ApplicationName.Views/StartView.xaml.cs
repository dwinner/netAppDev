﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for StartView.xaml
    /// </summary>
    public partial class StartView : UserControl
    {
        /// <summary>
        /// Initializes a new StartView object.
        /// </summary>
        public StartView()
        {
            InitializeComponent();
        }
    }
}
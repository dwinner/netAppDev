﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for SpreadsheetView.xaml
    /// </summary>
    public partial class SpreadsheetView : UserControl
    {
        /// <summary>
        /// Initializes a new SpreadsheetView object.
        /// </summary>
        public SpreadsheetView()
        {
            InitializeComponent();
        }
    }
}
﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for FeedbackView.xaml
    /// </summary>
    public partial class FeedbackView : UserControl
    {
        /// <summary>
        /// Initializes a new FeedbackView object.
        /// </summary>
        public FeedbackView()
        {
            InitializeComponent();
        }
    }
}
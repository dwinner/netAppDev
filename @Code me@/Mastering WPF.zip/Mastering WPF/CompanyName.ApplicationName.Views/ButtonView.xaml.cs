﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Interaction logic for ButtonView.xaml
    /// </summary>
    public partial class ButtonView : UserControl
    {
        /// <summary>
        /// Initializes a new ButtonView object.
        /// </summary>
        public ButtonView()
        {
            InitializeComponent();
        }
    }
}
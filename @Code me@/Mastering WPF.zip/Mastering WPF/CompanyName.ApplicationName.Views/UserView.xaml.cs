﻿using System.Windows.Controls;

namespace CompanyName.ApplicationName.Views
{
    /// <summary>
    /// Demonstrates different ways to render text in the View.
    /// </summary>
    public partial class UserView : UserControl
    {
        /// <summary>
        /// Initializes a new UserView object.
        /// </summary>
        public UserView()
        {
            InitializeComponent();
        }
    }
}
﻿namespace ServiceStack.Succinctly.ServiceInterface.OrderItemModel
{
    public class GetOrderItem
    {
        public int OrderId { get; set; }
        public int ItemId { get; set; }
    }
}
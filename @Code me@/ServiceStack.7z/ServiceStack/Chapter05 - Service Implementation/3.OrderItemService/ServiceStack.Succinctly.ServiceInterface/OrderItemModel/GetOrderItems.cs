﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServiceStack.Succinctly.ServiceInterface.OrderItemModel
{
    public class GetOrderItems
    {
        public int OrderId { get; set; }
    }

}

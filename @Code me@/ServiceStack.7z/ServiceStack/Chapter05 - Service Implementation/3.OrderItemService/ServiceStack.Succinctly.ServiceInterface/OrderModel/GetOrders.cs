﻿namespace ServiceStack.Succinctly.ServiceInterface.OrderModel
{
    public class GetOrders { }
}
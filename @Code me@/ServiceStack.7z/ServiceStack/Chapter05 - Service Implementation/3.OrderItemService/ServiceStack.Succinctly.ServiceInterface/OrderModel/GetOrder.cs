﻿namespace ServiceStack.Succinctly.ServiceInterface.OrderModel
{
    public class GetOrder
    {
        public int Id { get; set; }
    }
}
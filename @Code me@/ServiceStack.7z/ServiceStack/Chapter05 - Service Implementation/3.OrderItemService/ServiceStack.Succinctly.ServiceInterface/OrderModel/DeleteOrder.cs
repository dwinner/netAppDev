﻿namespace ServiceStack.Succinctly.ServiceInterface.OrderModel
{
    public class DeleteOrder
    {
        public int Id { get; set; }
    }
}
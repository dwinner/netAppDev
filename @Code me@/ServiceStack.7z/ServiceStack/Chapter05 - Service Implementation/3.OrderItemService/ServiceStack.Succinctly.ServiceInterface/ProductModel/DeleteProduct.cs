﻿namespace ServiceStack.Succinctly.ServiceInterface.ProductModel
{
    public class DeleteProduct
    {
        public int Id { get; set; }
    }
}
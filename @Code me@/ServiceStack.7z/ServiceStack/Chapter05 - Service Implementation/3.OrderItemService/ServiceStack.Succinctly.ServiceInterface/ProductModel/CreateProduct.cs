﻿namespace ServiceStack.Succinctly.ServiceInterface.ProductModel
{
    public class CreateProduct
    {
        public string Name { get; set; }
        public Status Status { get; set; }
    }
}
﻿namespace ServiceStack.Succinctly.ServiceInterface.ProductModel
{
    public class GetProducts { }
}
﻿namespace ServiceStack.Succinctly.ServiceInterface.ProductModel
{
    public class GetProduct
    {
        public int Id { get; set; }
    }
}
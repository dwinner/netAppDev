﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
namespace ServiceStack.Succinctly.Host.Services
{
    public class OrderItemService : ServiceStack.ServiceInterface.Service
    {

    }
}
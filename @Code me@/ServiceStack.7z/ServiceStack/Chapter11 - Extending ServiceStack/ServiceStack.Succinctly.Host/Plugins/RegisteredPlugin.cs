﻿namespace ServiceStack.Succinctly.Host.Plugins
{
    public class RegisteredPlugin
    {
        public string Name { get; set; }
    }
}
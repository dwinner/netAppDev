﻿namespace ServiceStack.Succinctly.Host.Plugins
{
    public class RegisteredPluginsDTO
    {
        //.. used only as a route to the service
    }
}
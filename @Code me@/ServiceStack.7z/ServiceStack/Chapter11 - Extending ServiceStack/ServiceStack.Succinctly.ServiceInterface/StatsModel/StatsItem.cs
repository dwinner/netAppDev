﻿namespace ServiceStack.Succinctly.ServiceInterface.StatsModel
{
    public class StatsItem
    {
        public string ServiceName { get; set; }
        public long Value { get; set; }

    }
}
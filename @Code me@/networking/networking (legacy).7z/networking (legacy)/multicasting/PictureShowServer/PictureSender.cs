using System;

namespace Apress.Networking.Multicast
{
	/// <summary>
	/// Summary description for Sender.
	/// </summary>
	public class PictureSender
	{
		public PictureSender()
		{

		}
	}
}

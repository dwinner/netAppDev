﻿namespace StreamsAndAsync
{
    public class ResultObject
    {
        public object LocalResult { get; set; }
        public object RequestResult { get; set; }
    }
}
﻿using System.Linq;
using System.Threading.Tasks;

namespace TravelRecord.App.Model
{
   public class User : ViewModelBase
   {
      private string _confirmPassword;
      private string _email;
      private string _id;
      private string _password;

      public string Id
      {
         get => _id;
         set => SetProperty(ref _id, value);
      }

      public string Email
      {
         get => _email;
         set => SetProperty(ref _email, value);
      }

      public string Password
      {
         get => _password;
         set => SetProperty(ref _password, value);
      }

      public string ConfirmPassword
      {
         get => _confirmPassword;
         set => SetProperty(ref _confirmPassword, value);
      }

      public static async Task<bool> LoginAsync(string email, string password)
      {
         var isEmailEmpty = string.IsNullOrEmpty(email);
         var isPasswordEmpty = string.IsNullOrEmpty(password);

         if (isEmailEmpty || isPasswordEmpty)
         {
            return false;
         }

         try
         {
            var user = (await App.MobileService.GetTable<User>()
               .Where(u => u.Email == email)
               .ToListAsync()
               .ConfigureAwait(false))
               .FirstOrDefault();

            if (user != null)
            {
               App.User = user;
               return user.Password == password;
            }

            return false;
         }
         catch
         {
            return false;
         }
      }

      public static void Register(User user) => App.MobileService.GetTable<User>().InsertAsync(user);
   }
}
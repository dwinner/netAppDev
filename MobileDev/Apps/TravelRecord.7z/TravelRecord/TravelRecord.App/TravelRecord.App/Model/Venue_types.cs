﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using TravelRecord.App.Helpers;
// ReSharper disable CollectionNeverUpdated.Global

// ReSharper disable InconsistentNaming

namespace TravelRecord.App.Model
{
   public class Location
   {
      public string address { get; set; }
      public string crossStreet { get; set; }
      public double lat { get; set; }
      public double lng { get; set; }
      public int distance { get; set; }
      public string postalCode { get; set; }
      public string cc { get; set; }
      public string city { get; set; }
      public string state { get; set; }
      public string country { get; set; }
      public IList<string> formattedAddress { get; set; }
   }

   public class Category
   {
      public string id { get; set; }
      public string name { get; set; }
      public string pluralName { get; set; }
      public string shortName { get; set; }
      public bool primary { get; set; }
   }

   public class Venue
   {
      public string id { get; set; }
      public string name { get; set; }
      public Location location { get; set; }
      public IList<Category> categories { get; set; }

      public static async Task<List<Venue>> GetVenuesAsync(double latitude, double longitude)
      {
         List<Venue> venues;

         var url = VenueRoot.GenerateURL(latitude, longitude);

         using (var client = new HttpClient())
         {
            var response = await client.GetAsync(url).ConfigureAwait(false);
            var json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            var venueRoot = JsonConvert.DeserializeObject<VenueRoot>(json);

            venues = venueRoot.response.venues as List<Venue>;
         }

         return venues;
      }
   }

   public class Response
   {
      public IList<Venue> venues { get; set; }
   }

   public class VenueRoot
   {
      public Response response { get; set; }

      public static string GenerateURL(double latitude, double longitude) => string.Format(Constants.VenueSearch,
         latitude, longitude, Constants.ClientId, Constants.ClientSecret, DateTime.Now.ToString("yyyyMMdd"));
   }
}
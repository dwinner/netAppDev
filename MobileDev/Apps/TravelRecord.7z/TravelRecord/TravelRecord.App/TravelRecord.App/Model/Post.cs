﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.MobileServices;
using Newtonsoft.Json;

namespace TravelRecord.App.Model
{
   public class Post : ViewModelBase
   {
      private string _address;
      private string _categoryId;
      private string _categoryName;
      private DateTimeOffset _createDate;
      private int _distance;
      private string _experience;
      private string _id;
      private double _latitude;
      private double _longitude;
      private string _userId;
      private Venue _venue;
      private string _venueName;

      public string Id
      {
         get => _id;
         set => SetProperty(ref _id, value);
      }

      public string Experience
      {
         get => _experience;
         set => SetProperty(ref _experience, value);
      }

      public string VenueName
      {
         get => _venueName;
         set => SetProperty(ref _venueName, value);
      }

      public string CategoryId
      {
         get => _categoryId;
         set => SetProperty(ref _categoryId, value);
      }

      public string CategoryName
      {
         get => _categoryName;
         set => SetProperty(ref _categoryName, value);
      }

      public string Address
      {
         get => _address;
         set => SetProperty(ref _address, value);
      }

      public double Latitude
      {
         get => _latitude;
         set => SetProperty(ref _latitude, value);
      }

      public double Longitude
      {
         get => _longitude;
         set => SetProperty(ref _longitude, value);
      }

      public int Distance
      {
         get => _distance;
         set => SetProperty(ref _distance, value);
      }

      public string UserId
      {
         get => _userId;
         set => SetProperty(ref _userId, value);
      }

      [JsonIgnore]
      public Venue Venue
      {
         get => _venue;
         set
         {
            _venue = value;

            var firstCategory = _venue.categories?.FirstOrDefault();

            if (firstCategory != null)
            {
               CategoryId = firstCategory.id;
               CategoryName = firstCategory.name;
            }

            if (_venue.location != null)
            {
               Address = _venue.location.address;
               Distance = _venue.location.distance;
               Latitude = _venue.location.lat;
               Longitude = _venue.location.lng;
            }

            VenueName = _venue.name;
            UserId = App.User.Id;

            OnPropertyChanged(nameof(Venue));
         }
      }

      public DateTimeOffset CreateDate
      {
         get => _createDate;
         set => SetProperty(ref _createDate, value);
      }

      public static async void Insert(Post post)
      {
         await App.PostsTable.InsertAsync(post).ConfigureAwait(true);
         await App.MobileService.SyncContext.PushAsync().ConfigureAwait(true);
      }

      public static async Task DeleteAsync(Post post)
      {
         try
         {
            await App.PostsTable.DeleteAsync(post).ConfigureAwait(false);
            await App.MobileService.SyncContext.PushAsync().ConfigureAwait(false);
         }
         catch
         {
            // ignored
         }
      }

      public static async Task<List<Post>> ReadAsync()
      {
         var posts = await App.PostsTable.Where(p => p.UserId == App.User.Id).ToListAsync().ConfigureAwait(false);
         return posts;
      }

      public static Dictionary<string, int> PostCategories(List<Post> posts)
      {
         var categories =
            (from post in posts
               orderby post.CategoryId
               select post.CategoryName).Distinct().ToList();

         var categoriesCount = new Dictionary<string, int>();
         foreach (var category in categories)
         {
            var count = (from post in posts
               where post.CategoryName == category
               select post).ToList().Count;

            categoriesCount.Add(category, count);
         }

         return categoriesCount;
      }
   }
}
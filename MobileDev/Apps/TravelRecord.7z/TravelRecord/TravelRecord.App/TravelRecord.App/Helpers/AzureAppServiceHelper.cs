﻿#define OFFLNE_SYNC_ENABLED

using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.MobileServices;
using Microsoft.WindowsAzure.MobileServices.Sync;
// ReSharper disable WarningHighlighting

namespace TravelRecord.App.Helpers
{
   public class AzureAppServiceHelper
   {
      public static async Task SyncAsync()
      {
         ReadOnlyCollection<MobileServiceTableOperationError> syncErrors = null;

         try
         {
            await App.MobileService.SyncContext.PushAsync().ConfigureAwait(false);
            await App.PostsTable.PullAsync("userPosts", "").ConfigureAwait(false);
         }
         catch (MobileServicePushFailedException mspfe)
         {
            if (mspfe.PushResult != null)
            {
               syncErrors = mspfe.PushResult.Errors;
            }
         }
         catch
         {
            // ignored
         }

         if (syncErrors != null)
         {
            foreach (var error in syncErrors)
            {
               if (error.OperationKind == MobileServiceTableOperationKind.Update && error.Result != null)
               {
                  await error.CancelAndUpdateItemAsync(error.Result).ConfigureAwait(false);
               }
               else
               {
                  await error.CancelAndDiscardItemAsync().ConfigureAwait(false);
               }
            }
         }
      }
   }
}
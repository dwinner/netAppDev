﻿namespace TravelRecord.App.Helpers
{
   public class Constants
   {
      public const string VenueSearch =
         "https://api.foursquare.com/v2/venues/search?ll={0},{1}&client_id={2}&client_secret={3}&v={4}";

      public const string ClientId = "VVZJGZBQLBCYCZGR5FO4P2251GOQ43EGJGVSWNXDQKNULPIH";
      public const string ClientSecret = "SKZBFNHTHLIVULD1RG12YNUBETCKWBZGJBK5XPO0FF14OX0G";
   }
}
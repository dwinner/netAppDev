﻿using Microsoft.WindowsAzure.MobileServices;
using Microsoft.WindowsAzure.MobileServices.SQLiteStore;
using Microsoft.WindowsAzure.MobileServices.Sync;
using TravelRecord.App.Model;
using Xamarin.Forms;

namespace TravelRecord.App
{
   public partial class App
   {
      public static readonly MobileServiceClient MobileService =
         new MobileServiceClient("https://travelrecordapp.azurewebsites.net");

      public static IMobileServiceSyncTable<Post> PostsTable;

      public static User User = new User();

      public App()
      {
         InitializeComponent();
         MainPage = new NavigationPage(new MainPage());
      }

      public App(string databaseLocation)
      {
         InitializeComponent();

         MainPage = new NavigationPage(new MainPage());

         var store = new MobileServiceSQLiteStore(databaseLocation);
         store.DefineTable<Post>();

         MobileService.SyncContext.InitializeAsync(store);

         PostsTable = MobileService.GetSyncTable<Post>();
      }
   }
}
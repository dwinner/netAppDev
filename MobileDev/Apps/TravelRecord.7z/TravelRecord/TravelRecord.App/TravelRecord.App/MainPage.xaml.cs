﻿using System.ComponentModel;
using TravelRecord.App.ViewModel;
using Xamarin.Forms;

namespace TravelRecord.App
{
   [DesignTimeVisible(false)]
   public partial class MainPage
   {
      public MainPage()
      {
         InitializeComponent();

         var assembly = typeof(MainPage);
         const string assemblyName = "TravelRecord.App";
         BindingContext = new MainViewModel();
         iconImage.Source = ImageSource.FromResource($"{assemblyName}.Assets.Images.plane.png", assembly);
      }
   }
}
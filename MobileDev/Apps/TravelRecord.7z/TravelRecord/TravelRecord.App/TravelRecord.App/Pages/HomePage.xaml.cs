﻿using TravelRecord.App.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TravelRecord.App.Pages
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class HomePage
   {
      public HomePage()
      {
         InitializeComponent();

         BindingContext = new HomeViewModel();
         NavigationPage.SetHasBackButton(this, false);
      }
   }
}
﻿using TravelRecord.App.Model;
using Xamarin.Forms.Xaml;

namespace TravelRecord.App.Pages
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class ProfilePage
   {
      public ProfilePage()
      {
         InitializeComponent();
      }

      protected override async void OnAppearing()
      {
         base.OnAppearing();

         var postTable = await Post.ReadAsync().ConfigureAwait(true);
         var categoriesCount = Post.PostCategories(postTable);
         categoriesListView.ItemsSource = categoriesCount;
         postCountLabel.Text = postTable.Count.ToString();
      }
   }
}
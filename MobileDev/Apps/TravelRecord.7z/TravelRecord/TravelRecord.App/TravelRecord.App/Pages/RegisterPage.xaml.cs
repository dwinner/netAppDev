﻿using TravelRecord.App.ViewModel;
using Xamarin.Forms.Xaml;

namespace TravelRecord.App.Pages
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class RegisterPage
   {
      public RegisterPage()
      {
         InitializeComponent();
         BindingContext = new RegisterViewModel();
      }
   }
}
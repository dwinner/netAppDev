﻿using System;
using System.Collections.Generic;
using Plugin.Geolocator;
using Plugin.Geolocator.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using TravelRecord.App.Model;
using Xamarin.Forms.Maps;
using Xamarin.Forms.Xaml;
using Position = Xamarin.Forms.Maps.Position;

namespace TravelRecord.App.Pages
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class MapPage
   {
      public MapPage()
      {
         InitializeComponent();
      }

      protected override async void OnAppearing()
      {
         base.OnAppearing();

         try
         {
            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Location)
               .ConfigureAwait(true);
            if (status != PermissionStatus.Granted)
            {
               if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Location)
                  .ConfigureAwait(true))
               {
                  await DisplayAlert("Need permission", "We will have to access your location for this", "Ok")
                     .ConfigureAwait(true);
               }

               var results = await CrossPermissions.Current.RequestPermissionsAsync(Permission.Location)
                  .ConfigureAwait(true);
               status = results[Permission.Location];
            }

            if (status == PermissionStatus.Granted)
            {
               locationsMap.IsShowingUser = true;
               var locator = CrossGeolocator.Current;
               locator.PositionChanged += Locator_PositionChanged;
               await locator.StartListeningAsync(TimeSpan.FromSeconds(0), 100).ConfigureAwait(true);

               var position = await locator.GetPositionAsync().ConfigureAwait(true);

               var center = new Position(position.Latitude, position.Longitude);
               var span = new MapSpan(center, 2, 2);
               locationsMap.MoveToRegion(span);

               var posts = await Post.ReadAsync().ConfigureAwait(true);
               DisplayInMap(posts);
            }
         }
         catch
         {
            await DisplayAlert("No permission", "You didn't grant permission for us to access your device's lcoation",
               "Ok").ConfigureAwait(true);
         }
      }

      protected override void OnDisappearing()
      {
         base.OnDisappearing();

         var locator = CrossGeolocator.Current;
         locator.PositionChanged -= Locator_PositionChanged;

         locator.StopListeningAsync();
      }

      private void DisplayInMap(IEnumerable<Post> posts)
      {
         foreach (var post in posts)
         {
            try
            {
               var position = new Position(post.Latitude, post.Longitude);
               var pin = new Pin
               {
                  Type = PinType.SavedPin,
                  Position = position,
                  Label = post.VenueName,
                  Address = post.Address
               };

               locationsMap.Pins.Add(pin);
            }
            catch
            {
               // ignored
            }
         }
      }

      private void Locator_PositionChanged(object sender, PositionEventArgs e)
      {
         var center = new Position(e.Position.Latitude, e.Position.Longitude);
         var span = new MapSpan(center, 2, 2);
         locationsMap.MoveToRegion(span);
      }
   }
}
﻿using System;
using TravelRecord.App.Helpers;
using TravelRecord.App.Model;
using TravelRecord.App.ViewModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace TravelRecord.App.Pages
{
   [XamlCompilation(XamlCompilationOptions.Compile)]
   public partial class HistoryPage
   {
      private readonly HistoryViewModel _viewModel;

      public HistoryPage()
      {
         InitializeComponent();

         _viewModel = new HistoryViewModel();
         BindingContext = _viewModel;
      }

      protected override async void OnAppearing()
      {
         base.OnAppearing();

         await _viewModel.UpdatePostsAsync().ConfigureAwait(true);
         await AzureAppServiceHelper.SyncAsync().ConfigureAwait(true);
      }

      private void MenuItem_Clicked(object sender, EventArgs e)
      {
         var post = (Post) ((MenuItem) sender).CommandParameter;
         HistoryViewModel.DeletePost(post);
#pragma warning disable 4014
         _viewModel.UpdatePostsAsync();
#pragma warning restore 4014
      }

      private async void OnRefreshing(object sender, EventArgs e)
      {
         await _viewModel.UpdatePostsAsync().ConfigureAwait(true);
         await AzureAppServiceHelper.SyncAsync().ConfigureAwait(true);
         postListView.IsRefreshing = false;
      }
   }
}
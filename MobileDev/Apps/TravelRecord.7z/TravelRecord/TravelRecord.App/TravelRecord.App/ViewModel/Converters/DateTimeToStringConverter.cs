﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace TravelRecord.App.ViewModel.Converters
{
   public class DateTimeToStringConverter : IValueConverter
   {
      public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
      {
         var dateTime = (DateTimeOffset) value;
         var rightNow = DateTimeOffset.Now;
         var difference = rightNow - dateTime;

         return difference.TotalDays > 1
            ? $"{dateTime:d}"
            : difference.TotalSeconds < 60
               ? $"{difference.TotalSeconds:0} seconds ago"
               : difference.TotalMinutes < 60
                  ? $"{difference.TotalMinutes:0} minutes ago"
                  : difference.TotalHours < 24
                     ? $"{difference.TotalHours:0} hours ago"
                     : "yesterday";
      }

      public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
         DateTimeOffset.Now;
   }
}
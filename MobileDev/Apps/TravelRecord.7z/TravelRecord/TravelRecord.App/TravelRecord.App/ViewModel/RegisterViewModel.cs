﻿using TravelRecord.App.Model;
using TravelRecord.App.ViewModel.Commands;

namespace TravelRecord.App.ViewModel
{
   public class RegisterViewModel : ViewModelBase
   {
      private string _confirmPassword;
      private string _email;
      private string _password;
      private User _user;

      public RegisterViewModel() => RegisterCommand = new RegisterCommand(this);

      public string Email
      {
         get => _email;
         set
         {
            _email = value;
            User = new User
            {
               Email = Email,
               Password = Password,
               ConfirmPassword = ConfirmPassword
            };
            OnPropertyChanged();
         }
      }

      public string Password
      {
         get => _password;
         set
         {
            _password = value;
            User = new User
            {
               Email = Email,
               Password = Password,
               ConfirmPassword = ConfirmPassword
            };
            OnPropertyChanged();
         }
      }

      public string ConfirmPassword
      {
         get => _confirmPassword;
         set
         {
            _confirmPassword = value;
            User = new User
            {
               Email = Email,
               Password = Password,
               ConfirmPassword = ConfirmPassword
            };
            OnPropertyChanged();
         }
      }

      public User User
      {
         get => _user;
         set => SetProperty(ref _user, value);
      }

      public RegisterCommand RegisterCommand { get; set; }

      public void Register(User aUser) => User.Register(aUser);
   }
}
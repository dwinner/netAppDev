﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using TravelRecord.App.Model;

namespace TravelRecord.App.ViewModel
{
   public class HistoryViewModel
   {
      public HistoryViewModel() => Posts = new ObservableCollection<Post>();

      public ObservableCollection<Post> Posts { get; set; }

      public async Task UpdatePostsAsync()
      {
         try
         {
            var posts = await Post.ReadAsync().ConfigureAwait(true);
            if (posts != null)
            {
               Posts.Clear();
               foreach (var post in posts)
               {
                  Posts.Add(post);
               }
            }
         }
         catch
         {
            // ignored
         }
      }

      public static void DeletePost(Post postToDelete)
      {
#pragma warning disable 4014
         Post.DeleteAsync(postToDelete);
#pragma warning restore 4014
      }
   }
}
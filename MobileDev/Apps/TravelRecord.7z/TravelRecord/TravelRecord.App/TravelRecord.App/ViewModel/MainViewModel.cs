﻿using TravelRecord.App.Model;
using TravelRecord.App.Pages;
using TravelRecord.App.ViewModel.Commands;
using Xamarin.Forms;

namespace TravelRecord.App.ViewModel
{
   public class MainViewModel : ViewModelBase
   {
      private string _email;
      private string _password;
      private User _user;

      public MainViewModel()
      {
         User = new User();
         LoginCommand = new LoginCommand(this);
         RegisterNavigationCommand = new RegisterNavigationCommand(this);
      }

      public User User
      {
         get => _user;
         set => SetProperty(ref _user, value);
      }

      public RegisterNavigationCommand RegisterNavigationCommand { get; set; }

      public LoginCommand LoginCommand { get; set; }

      public string Email
      {
         get => _email;
         set
         {
            _email = value;
            User = new User
            {
               Email = Email,
               Password = Password
            };
            OnPropertyChanged();
         }
      }

      public string Password
      {
         get => _password;
         set
         {
            _password = value;
            User = new User
            {
               Email = Email,
               Password = Password
            };
            OnPropertyChanged();
         }
      }

      public async void Login()
      {
         var canLogin = await User.LoginAsync(User.Email, User.Password).ConfigureAwait(true);
         if (canLogin)
         {
            await Application.Current.MainPage.Navigation.PushAsync(new HomePage()).ConfigureAwait(true);
         }
         else
         {
            await Application.Current.MainPage.DisplayAlert("Error", "Try again", "Ok").ConfigureAwait(true);
         }
      }

      public void Navigate() => Application.Current.MainPage.Navigation.PushAsync(new RegisterPage());
   }
}
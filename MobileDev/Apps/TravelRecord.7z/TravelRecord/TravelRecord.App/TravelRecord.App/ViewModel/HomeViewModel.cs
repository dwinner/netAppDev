﻿using TravelRecord.App.Pages;
using TravelRecord.App.ViewModel.Commands;
using Xamarin.Forms;

namespace TravelRecord.App.ViewModel
{
   public class HomeViewModel
   {
      public HomeViewModel() => NavCommand = new NavigationCommand(this);

      public NavigationCommand NavCommand { get; set; }

      public void Navigate() => Application.Current.MainPage.Navigation.PushAsync(new NewTravelPage());
   }
}
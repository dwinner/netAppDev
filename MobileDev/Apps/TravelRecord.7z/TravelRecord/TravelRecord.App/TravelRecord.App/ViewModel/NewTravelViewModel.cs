﻿using TravelRecord.App.Model;
using TravelRecord.App.ViewModel.Commands;
using Xamarin.Forms;

namespace TravelRecord.App.ViewModel
{
   public class NewTravelViewModel : ViewModelBase
   {
      private string _experience;
      private Post _post;
      private Venue _venue;

      public NewTravelViewModel()
      {
         PostCommand = new PostCommand(this);
         Post = new Post();
         Venue = new Venue();
      }

      public PostCommand PostCommand { get; set; }

      public Post Post
      {
         get => _post;
         set => SetProperty(ref _post, value);
      }

      public string Experience
      {
         get => _experience;
         set
         {
            _experience = value;
            Post = new Post
            {
               Experience = Experience,
               Venue = _venue
            };

            OnPropertyChanged(nameof(Experience));
         }
      }

      public Venue Venue
      {
         get => _venue;
         set
         {
            _venue = value;
            Post = new Post
            {
               Experience = Experience,
               Venue = _venue
            };

            OnPropertyChanged(nameof(Venue));
         }
      }

      public static async void PublishPost(Post aPost)
      {
         try
         {
            Post.Insert(aPost);
            await Application.Current.MainPage.DisplayAlert("Success", "Experience succesfully inserter", "Ok").ConfigureAwait(true);
         }
         catch
         {
            await Application.Current.MainPage.DisplayAlert("Failure", "Experience failed to be inserted", "Ok").ConfigureAwait(true);
         }
      }
   }
}
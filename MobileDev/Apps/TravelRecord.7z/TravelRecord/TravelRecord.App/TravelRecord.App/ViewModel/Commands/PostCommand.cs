﻿using System;
using System.Windows.Input;
using TravelRecord.App.Annotations;
using TravelRecord.App.Model;
// ReSharper disable NotAccessedField.Local

namespace TravelRecord.App.ViewModel.Commands
{
   public class PostCommand : ICommand
   {
      [UsedImplicitly] private readonly NewTravelViewModel _viewModel;

      public PostCommand(NewTravelViewModel viewModel) => _viewModel = viewModel;

      public event EventHandler CanExecuteChanged;

      public bool CanExecute(object parameter)
      {
         var post = (Post) parameter;
         return post != null && !string.IsNullOrEmpty(post.Experience) && post.Venue != null;
      }

      public void Execute(object parameter)
      {
         var post = (Post) parameter;
         NewTravelViewModel.PublishPost(post);
      }
   }
}
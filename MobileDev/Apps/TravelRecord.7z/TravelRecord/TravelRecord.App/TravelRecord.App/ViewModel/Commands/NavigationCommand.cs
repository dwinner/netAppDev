﻿using System;
using System.Windows.Input;

namespace TravelRecord.App.ViewModel.Commands
{
   public class NavigationCommand : ICommand
   {
      public NavigationCommand(HomeViewModel homeViewModel) => HomeViewModel = homeViewModel;

      public HomeViewModel HomeViewModel { get; set; }

      public event EventHandler CanExecuteChanged;

      public bool CanExecute(object parameter) => true;

      public void Execute(object parameter) => HomeViewModel.Navigate();
   }
}
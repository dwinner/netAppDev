﻿using System;
using System.Windows.Input;
using TravelRecord.App.Model;

namespace TravelRecord.App.ViewModel.Commands
{
   public class RegisterCommand : ICommand
   {
      private readonly RegisterViewModel _viewModel;

      public RegisterCommand(RegisterViewModel viewModel) => _viewModel = viewModel;

      public event EventHandler CanExecuteChanged;

      public bool CanExecute(object parameter)
      {
         var user = (User) parameter;
         return user != null && user.Password == user.ConfirmPassword
                             && !string.IsNullOrEmpty(user.Email)
                             && !string.IsNullOrEmpty(user.Password);
      }

      public void Execute(object parameter)
      {
         var user = (User) parameter;
         _viewModel.Register(user);
      }
   }
}
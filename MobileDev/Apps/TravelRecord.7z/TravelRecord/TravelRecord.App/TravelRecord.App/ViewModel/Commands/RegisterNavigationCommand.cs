﻿using System;
using System.Windows.Input;

namespace TravelRecord.App.ViewModel.Commands
{
   public class RegisterNavigationCommand : ICommand
   {
      private readonly MainViewModel viewModel;

      public RegisterNavigationCommand(MainViewModel viewModel) => this.viewModel = viewModel;

      public event EventHandler CanExecuteChanged;

      public bool CanExecute(object parameter) => true;

      public void Execute(object parameter)
      {
         viewModel.Navigate();
      }
   }
}
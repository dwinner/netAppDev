﻿using System;
using System.Windows.Input;
using TravelRecord.App.Model;

namespace TravelRecord.App.ViewModel.Commands
{
   public class LoginCommand : ICommand
   {
      public LoginCommand(MainViewModel viewModel) => ViewModel = viewModel;

      public MainViewModel ViewModel { get; set; }

      public event EventHandler CanExecuteChanged;

      public bool CanExecute(object parameter)
      {
         var user = (User) parameter;
         return user != null && !string.IsNullOrEmpty(user.Email) && !string.IsNullOrEmpty(user.Password);
      }

      public void Execute(object parameter) => ViewModel.Login();
   }
}
﻿using System;
using System.IO;
using Foundation;
using Microsoft.WindowsAzure.MobileServices;
using UIKit;
using Xamarin;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

namespace TravelRecord.App.iOS
{
   [Register(nameof(AppDelegate))]
   public class AppDelegate : FormsApplicationDelegate
   {
      public override bool FinishedLaunching(UIApplication app, NSDictionary options)
      {
         Forms.SetFlags("FastRenderers_Experimental");
         Forms.Init();
         FormsMaps.Init();
         CurrentPlatform.Init();

         const string dbName = "travel_db.sqlite";
         var folderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "..", "Library");
         var databaseLocation = Path.Combine(folderPath, dbName);

         LoadApplication(new App(databaseLocation));

         return base.FinishedLaunching(app, options);
      }
   }
}
﻿using UIKit;

namespace TravelRecord.App.iOS
{
   public class Application
   {
      private static void Main(string[] args)
      {
         UIApplication.Main(args, null, nameof(AppDelegate));
      }
   }
}
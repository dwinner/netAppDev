﻿
// Copyright Christophe Bertrand.

using System;
namespace UniversalSerializerResourceTests
{
	public class SerializableAttribute : Attribute
	{
	}

	public class TextBox
	{
		public string Text { get; set; }
	}
}
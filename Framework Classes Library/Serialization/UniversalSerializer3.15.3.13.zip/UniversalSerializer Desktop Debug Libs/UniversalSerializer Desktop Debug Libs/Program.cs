﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversalSerializer_Desktop_Debug_Libs
{
	class Program
	{
		static void Main(string[] args)
		{
		}
	}
}

﻿
// Copyright Christophe Bertrand.

// For future use.


namespace UniversalSerializerLib3
{
	internal class Main
	{
		internal static Main StaticMain = new Main();

		internal Main()
		{
		}
	}
}

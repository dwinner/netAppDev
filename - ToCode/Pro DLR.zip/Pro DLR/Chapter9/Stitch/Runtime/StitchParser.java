// $ANTLR 3.1.2 C:\\ProDLR\\src\\Examples\\Chapter9\\Eclipse\\Stitch\\src\\Stitch.g 2010-08-02 17:09:15

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class StitchParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", 
    };
    public static final int EOF=-1;

    // delegates
    // delegators


        public StitchParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public StitchParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return StitchParser.tokenNames; }
    public String getGrammarFileName() { return "C:\\ProDLR\\src\\Examples\\Chapter9\\Eclipse\\Stitch\\src\\Stitch.g"; }



    // $ANTLR start "rule"
    // C:\\ProDLR\\src\\Examples\\Chapter9\\Eclipse\\Stitch\\src\\Stitch.g:7:1: rule : ;
    public final void rule() throws RecognitionException {
        try {
            // C:\\ProDLR\\src\\Examples\\Chapter9\\Eclipse\\Stitch\\src\\Stitch.g:7:5: ()
            // C:\\ProDLR\\src\\Examples\\Chapter9\\Eclipse\\Stitch\\src\\Stitch.g:7:7: 
            {
            }

        }
        finally {
        }
        return ;
    }
    // $ANTLR end "rule"

    // Delegated rules


 

}
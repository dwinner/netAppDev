def add3(x): return x + 3


﻿namespace UnitTestingSamples
{
    public class DeepThought
    {
        public int TheAnswerToTheUltimateQuestionOfLifeTheUniverseAndEverything() => 42;
    }

}

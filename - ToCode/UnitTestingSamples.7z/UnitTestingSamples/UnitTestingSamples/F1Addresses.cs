﻿namespace UnitTestingSamples
{
    public class F1Addresses
    {
        public const string RacersUrl = "http://www.cninnovation.com/downloads/Racers.xml";
    }
}

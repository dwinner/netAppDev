﻿namespace UnitTestingSamplesCore
{
    public class DeepThought
    {
        public int TheAnswerToTheUltimateQuestionOfLifeTheUniverseAndEverything()
        {
            return 42;
        }
    }
}

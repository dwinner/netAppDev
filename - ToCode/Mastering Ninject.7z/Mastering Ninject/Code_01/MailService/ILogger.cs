namespace Samples.MailService
{
    interface ILogger
    {
        void Log(string message);
    }
}
namespace Samples
{
    class Carpenter
    {
        Saw saw = new Saw();
        void MakeChair()
        {
            saw.Cut();
            // ...
        }
    }
}


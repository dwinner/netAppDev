using System;

namespace Samples
{
    internal class Saw
    {
        public void Cut()
        {
            Console.WriteLine("Cutting...");
        }
    }
}
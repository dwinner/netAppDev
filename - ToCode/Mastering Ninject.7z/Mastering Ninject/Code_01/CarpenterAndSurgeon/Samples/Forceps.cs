using System;

namespace Samples
{
    public abstract class Forceps
    {
        public abstract void Grab();

    }
}
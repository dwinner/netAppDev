using System;

namespace Graphic.Core
{
    public interface ICircle :IShape
    {

    }
}
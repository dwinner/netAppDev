using System;

namespace Graphic.Core
{
    public interface ISquare :IShape
    {

    }
}
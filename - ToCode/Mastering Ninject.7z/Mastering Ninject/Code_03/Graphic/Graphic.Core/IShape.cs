namespace Graphic.Core
{
    public interface IShape
    {
    }
}
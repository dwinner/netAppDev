using System.Windows.Forms;

namespace UIFactory.Core
{
    public abstract class CheckBoxBase : Control
    {
    }
}
namespace MissingBindingResolverExample
{
    public interface IWriter
    {
        void Write();
    }
}
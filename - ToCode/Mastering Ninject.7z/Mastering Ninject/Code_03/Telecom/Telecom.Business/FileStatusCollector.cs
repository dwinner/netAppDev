using System;
using Telecom.Business.Model;

namespace Telecom.Business
{
    public class FileStatusCollector : IStatusCollector
    {
        public string GetStatus(Switch @switch)
        {
            throw new NotImplementedException();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Telecom.Business.Model
{
public class Switch
{
    public string Name { get; set; }

    public string Vendor { get; set; }

    public bool SupportsTcpIp { get; set; }
}
}

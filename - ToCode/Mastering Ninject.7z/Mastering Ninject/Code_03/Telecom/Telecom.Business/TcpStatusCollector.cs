using System;
using Telecom.Business.Model;

namespace Telecom.Business
{
    public class TcpStatusCollector : IStatusCollector
    {
        public string GetStatus(Switch @switch)
        {
            throw new NotImplementedException();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataMigration.Business
{
    public class SourceAttribute : Attribute
    {
    }

    public class TargetAttribute : Attribute
    {
    }
}

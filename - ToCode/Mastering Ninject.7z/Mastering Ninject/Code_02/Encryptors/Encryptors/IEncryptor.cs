namespace Samples.Encryption
{
    public interface IEncryptor
    {
        string Encrypt(string str);
    }
}
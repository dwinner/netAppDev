The code is written in Visual Studio .Net 2012.
Open the project file (csproj) or the solution (sln) using Visual Studio .Net 2012.
You will need to add reference to required libraries and packages. Do it as is described in the book.
The databse which is used is Northwind. It is the sample database of Microsoft SQL server and if you have SQL Server installed on your computer, it is already in its Samples directory.
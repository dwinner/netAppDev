﻿using System;

namespace Northwind.Core
{
    public class InjectAttribute : Attribute
    {
    }
}

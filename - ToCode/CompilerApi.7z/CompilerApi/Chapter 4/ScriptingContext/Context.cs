﻿namespace ScriptingContext
{
	public sealed class Context
	{
		public Context(int value)
		{
			this.Value = value;
		}

		public int Value { get; }
	}
}

﻿namespace PlayingWithInteractive
{
	public class MyValue
	{
		private readonly int value;

		public MyValue(int value)
		{
			this.value = value;
		}

		public int Value
		{
			get { return this.value; }
		}
	}
}

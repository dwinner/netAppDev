﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntegrationTests
{
	public class Class1
	{
		/// <summary>
		/// 
		/// </summary>
		public void Foo()
		{
			var x = 42;
		}
	}
}
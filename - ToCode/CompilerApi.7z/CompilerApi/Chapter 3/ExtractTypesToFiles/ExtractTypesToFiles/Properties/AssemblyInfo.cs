﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ExtractTypesToFiles")]
[assembly: AssemblyProduct("ExtractTypesToFiles")]
[assembly: AssemblyCopyright("Copyright ©  2016")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: InternalsVisibleTo("ExtractTypesToFiles.Tests")]

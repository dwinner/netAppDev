﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ExtractTypesToFiles.Tests.Extensions
{
	[TestClass]
	public sealed class MemberDeclarationSyntaxExtensionsTests
	{
	}
}

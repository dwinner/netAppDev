﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace ExtractTypesToFiles.Tests.Targets.Extensions.SyntaxNodeExtensionsTests
{
	public sealed class Class1
	{
		public void ProcessContent(Guid id, Stream stream, StringBuilder builder) { }
	}
}

﻿namespace ExtractTypesToFiles.Tests.Targets.ExtractTypesToFilesCodeRefactoringProviderTests
{
	public class Class1 { }
	public class Class2 { }
}

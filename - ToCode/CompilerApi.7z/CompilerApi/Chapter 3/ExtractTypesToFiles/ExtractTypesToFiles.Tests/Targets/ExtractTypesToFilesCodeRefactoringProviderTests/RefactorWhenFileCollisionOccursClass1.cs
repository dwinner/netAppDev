﻿namespace ExtractTypesToFiles.Tests.Targets.ExtractTypesToFilesCodeRefactoringProviderTests
{
    public class Class1 { }
}
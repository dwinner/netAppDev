﻿namespace IntegrationTests.SubNamespace
{
	public class Class3
	{
	}
}
﻿namespace BuildingTrees
{
	public static class Doubler
	{
		public static int Double(int a)
		{
			return 2 * a;
		}
	}
}

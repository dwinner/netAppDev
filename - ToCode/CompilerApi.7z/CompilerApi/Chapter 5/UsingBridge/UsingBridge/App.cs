﻿using Bridge.Html5;

namespace UsingBridge
{
	public static class App
	{
		[Ready]
		public static void Main()
		{
			Window.Alert("Welcome to Bridge.NET");
		}
	}
}

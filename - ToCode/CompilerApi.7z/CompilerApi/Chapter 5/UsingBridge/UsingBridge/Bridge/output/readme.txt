NOTE:   Your Bridge.NET JavaScript files are in this 
        directory, but Visual Studio may be hiding. 

        Click on the "Show All Files" button within your 
        Visual Studio Solution Explorer panel, or browse 
        directly to this folder within the file system.

        ------------------------------------------------

        Please see /App_Readme/Bridge.NET/README.txt for
        more information about this release.

        ------------------------------------------------

        A copy of the Bridge.NET License copied to 
        /App_Readme/Bridge.NET/LICENSE.txt
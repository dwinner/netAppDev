﻿namespace UsingRocks
{
	public interface IService
	{
		int GetId();
	}
}

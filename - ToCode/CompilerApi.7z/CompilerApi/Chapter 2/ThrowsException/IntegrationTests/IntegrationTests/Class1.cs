﻿namespace IntegrationTests
{
	public class Class1
	{
		public void AMethod() { }

		public int AnotherMethod() { return 44; }
	}
}

﻿using System.Reflection;

[assembly: AssemblyTitle("MustInvokeBaseMethod.Analyzers")]
[assembly: AssemblyProduct("MustInvokeBaseMethod.Analyzers")]
[assembly: AssemblyCopyright("Copyright ©  2016")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

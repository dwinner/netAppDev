﻿
namespace PostSharpExamples
{
	[ToString]
	public sealed class ClassWithoutToString { }
}

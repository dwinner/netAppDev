﻿namespace PostSharpExamples
{
	[Equals]
	public sealed class ClassWithEquals
	{
		public int IntData { get; set; }
		public string StringData { get; set; }
	}
}

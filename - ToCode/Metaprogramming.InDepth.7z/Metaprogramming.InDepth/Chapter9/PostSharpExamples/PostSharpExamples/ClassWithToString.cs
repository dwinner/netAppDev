﻿namespace PostSharpExamples
{
	public sealed class ClassWithToString
	{
		public override string ToString()
		{
			return "ClassWithToString";
		}
	}
}

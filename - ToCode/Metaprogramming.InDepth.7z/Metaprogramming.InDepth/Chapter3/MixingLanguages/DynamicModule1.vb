﻿Module Module1
  Sub Main()
    Console.WriteLine("Hello, world!")
  End Sub
End Module

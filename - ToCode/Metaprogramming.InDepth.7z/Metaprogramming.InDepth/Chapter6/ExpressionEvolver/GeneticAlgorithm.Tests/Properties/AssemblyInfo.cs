﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("www.jasonbock.net")]
[assembly: AssemblyCopyright("Copyright © jasonbock.net 2010")]
[assembly: AssemblyDescription("An assembly that contains tests for GeneticAlgorithm.")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("GeneticAlgorithm.Tests")]
[assembly: AssemblyTitle("GeneticAlgorithm.Tests")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
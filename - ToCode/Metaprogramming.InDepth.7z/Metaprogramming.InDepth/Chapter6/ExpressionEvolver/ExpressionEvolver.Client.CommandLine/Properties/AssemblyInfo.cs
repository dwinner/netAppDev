﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("www.jasonbock.net")]
[assembly: AssemblyCopyright("Copyright © jasonbock.net 2010")]
[assembly: AssemblyDescription("A console application that demonstrates the evolution of LINQ expressions in ExpressionEvolver.")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("ExpressionEvolver.Client.CommandLine")]
[assembly: AssemblyTitle("ExpressionEvolver.Client.CommandLine")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]

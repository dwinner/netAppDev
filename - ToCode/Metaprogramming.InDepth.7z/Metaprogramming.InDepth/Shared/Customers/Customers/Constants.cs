﻿using System;

namespace Customers
{
	public static class Constants
	{
		public const string Separator = " || ";
	}
}

﻿namespace DynamicMocks.Roslyn.Tests
{
	public sealed class SimpleCallbackWithNoMethods
		: Recorder
	{
		public SimpleCallbackWithNoMethods()
			: base() { }
	}
}

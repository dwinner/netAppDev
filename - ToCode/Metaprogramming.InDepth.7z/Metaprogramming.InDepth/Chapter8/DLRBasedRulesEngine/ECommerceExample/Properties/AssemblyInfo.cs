﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ECommerceExample")]
[assembly: AssemblyDescription("Example for Chapter 8 of http://manning.com/hazzard")]
#if DEBUG
[assembly: AssemblyConfiguration("DEBUG")]
#else
[assembly: AssemblyConfiguration("RELEASE")]
#endif
[assembly: AssemblyCompany("Manning.com")]
[assembly: AssemblyProduct("Metaprogramming in .NET Book")]
[assembly: AssemblyCopyright("This material is in the public domain and comes with no warranties or guarantees.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("1ae4f808-e8a9-4679-86de-7c44bb018501")]
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyFileVersion("1.0.*")]

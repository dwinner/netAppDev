﻿using Windows.UI.Xaml.Controls;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace FuelEconomyUWP
{
    public sealed partial class FuelEconomyUC : UserControl
    {
        public FuelEconomyUC()
        {
            this.InitializeComponent();
        }
    }
}

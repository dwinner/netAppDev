﻿namespace Wrox.ProCSharp.Composition
{
    public interface ICalculatorExtension
  {
    // returns a FrameworkElement
    object UI { get; }
  }
}

﻿namespace CalculatorContract
{
    public interface IBinaryOperation
    {
        double Operation(double x, double y);
    }
}

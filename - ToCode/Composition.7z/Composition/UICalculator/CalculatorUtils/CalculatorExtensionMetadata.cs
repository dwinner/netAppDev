﻿namespace Wrox.ProCSharp.Composition
{
    public class CalculatorExtensionMetadata
    {
        public string Title { get; }
        public string Description { get; }
        public string ImageUri { get; }
    }
}

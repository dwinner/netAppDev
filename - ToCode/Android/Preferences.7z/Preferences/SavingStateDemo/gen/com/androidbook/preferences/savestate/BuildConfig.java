/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.preferences.savestate;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
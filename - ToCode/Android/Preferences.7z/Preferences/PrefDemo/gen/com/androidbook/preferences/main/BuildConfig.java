/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.preferences.main;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.styles;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
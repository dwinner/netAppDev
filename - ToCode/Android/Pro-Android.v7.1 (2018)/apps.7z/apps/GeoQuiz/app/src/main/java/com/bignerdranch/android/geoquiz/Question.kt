package com.bignerdranch.android.geoquiz

data class Question(val textResId: Int, val isAnswerTrue: Boolean)
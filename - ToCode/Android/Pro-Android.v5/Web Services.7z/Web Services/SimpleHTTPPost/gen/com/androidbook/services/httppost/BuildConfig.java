/** Automatically generated file. DO NOT MODIFY */
package com.androidbook.services.httppost;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
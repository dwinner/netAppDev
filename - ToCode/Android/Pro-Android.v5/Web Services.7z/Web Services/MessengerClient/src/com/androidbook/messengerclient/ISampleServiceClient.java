package com.androidbook.messengerclient;

public interface ISampleServiceClient {
    public void updateStatus(String status);
}

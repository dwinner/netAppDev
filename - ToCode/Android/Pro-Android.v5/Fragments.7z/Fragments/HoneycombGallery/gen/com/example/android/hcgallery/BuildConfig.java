/** Automatically generated file. DO NOT MODIFY */
package com.example.android.hcgallery;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
CREATE TABLE t_books (id INTEGER PRIMARY KEY,
                name TEXT,
                isbn TEXT,
                author TEXT,
                created_on INTEGER,
                created_by TEXT,
                last_updated_on INTEGER,
                last_updated_by TEXT
);

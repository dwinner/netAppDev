﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace SportsStore.Infrastructure.Identity {

    public class StoreUser : IdentityUser {
        // application-specific properties go here
    }
}

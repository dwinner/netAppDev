﻿using System.Web.Mvc;

namespace SportsStore.Controllers {

    public class AdminController : Controller {

        public ActionResult Index() {
            return View();
        }
    }
}

﻿using System.Web.Mvc;

namespace SportsStore.Controllers {
    public class HomeController : Controller {

        public ActionResult Index() {
            return View();
        }
    }
}

﻿var adminModel = {
    currentView: ko.observable("signin"),
    listMode: ko.observable("products"),
    newProduct: { name: "" }
}

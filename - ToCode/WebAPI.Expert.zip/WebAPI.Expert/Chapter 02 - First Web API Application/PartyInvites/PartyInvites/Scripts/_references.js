﻿/// <reference path="jquery-2.1.0.js" />
/// <reference path="knockout-3.1.0.debug.js" />

﻿namespace Recipe2
{
    public class Painting
    {
        public string AccessionNumber { get; set; }
        public string Name { get; set; }
        public string Artist { get; set; }
        public decimal LastSalePrice { get; set; }
    }
}
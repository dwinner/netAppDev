﻿namespace Recipe4
{
    public class Reservation
    {
        public int ReservationId { get; set; }
        public System.DateTime ResDate { get; set; }
        public string Name { get; set; }
    }
}
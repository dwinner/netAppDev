﻿namespace Recipe4.Service.DAL
{
    public enum TrackingState
    {
        Nochange,
        Add,
        Update,
        Remove,
    }
}
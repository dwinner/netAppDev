﻿namespace Cities.Models {

    public enum CountryNames {
        UK,
        USA,
        France,
        China
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestingSamplesCore
{
    public class F1Addresses
    {
        public const string RacersUrl = "http://www.cninnovation.com/downloads/Racers.xml";
    }
}

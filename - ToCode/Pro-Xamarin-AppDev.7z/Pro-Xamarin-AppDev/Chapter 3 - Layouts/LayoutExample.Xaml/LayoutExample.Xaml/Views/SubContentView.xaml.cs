﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace LayoutExample.Xaml.Views
{
    public partial class SubContentView : ContentView
    {
        public SubContentView()
        {
            InitializeComponent();
        }
    }
}


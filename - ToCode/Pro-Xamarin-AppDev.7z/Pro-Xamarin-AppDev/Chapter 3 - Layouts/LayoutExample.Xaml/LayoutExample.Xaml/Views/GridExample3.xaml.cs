﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutExample.Xaml.Views
{
    public partial class GridExample3 : ContentPage
    {
        public GridExample3()
        {
            InitializeComponent();
        }
    }
}


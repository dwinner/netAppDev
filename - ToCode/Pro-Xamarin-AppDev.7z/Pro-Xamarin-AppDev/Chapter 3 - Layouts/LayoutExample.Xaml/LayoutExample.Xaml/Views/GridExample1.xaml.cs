﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutExample.Xaml.Views
{
    public partial class GridExample1 : ContentPage
    {
        public GridExample1()
        {
            InitializeComponent();
        }
    }
}


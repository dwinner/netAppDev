﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutExample.Xaml.Views
{
    public partial class StackLayoutVertical : ContentPage
    {
        public StackLayoutVertical()
        {
            InitializeComponent();
        }
    }
}


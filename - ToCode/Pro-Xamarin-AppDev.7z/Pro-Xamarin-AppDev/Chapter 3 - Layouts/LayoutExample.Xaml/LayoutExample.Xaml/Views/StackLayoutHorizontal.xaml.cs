﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutExample.Xaml.Views
{
    public partial class StackLayoutHorizontal : ContentPage
    {
        public StackLayoutHorizontal()
        {
            InitializeComponent();
        }
    }
}


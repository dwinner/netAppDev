﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace LayoutExample.Xaml.Views
{
    public partial class AbsoluteLayoutExample : ContentPage
    {
        public AbsoluteLayoutExample()
        {
            InitializeComponent();
        }
    }
}


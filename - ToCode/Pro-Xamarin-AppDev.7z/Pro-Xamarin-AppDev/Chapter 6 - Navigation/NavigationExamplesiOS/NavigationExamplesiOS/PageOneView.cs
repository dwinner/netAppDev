using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NavigationExamplesiOS
{
	partial class PageOneView : UIView
	{
		public PageOneView (IntPtr handle) : base (handle)
		{
		}
	}
}

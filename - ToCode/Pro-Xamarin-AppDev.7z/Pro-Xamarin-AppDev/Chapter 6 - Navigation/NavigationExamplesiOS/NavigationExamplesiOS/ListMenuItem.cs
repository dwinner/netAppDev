﻿using System;

namespace iOSListExample
{
	public class ListMenuItem
	{
		public string Title { get; set; }
		public Type PageType { get; set; }
	}

}


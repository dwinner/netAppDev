using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NavigationExamplesiOS
{
	partial class PageTwo : UIViewController
	{
		public PageTwo (IntPtr handle) : base (handle)
		{
		}
	}
}

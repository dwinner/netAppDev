using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NavigationExamplesiOS
{
	partial class PageTwoView : UIView
	{
		public PageTwoView (IntPtr handle) : base (handle)
		{
		}
	}
}

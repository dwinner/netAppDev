﻿using System;

namespace NavigationExamplesiOS
{
	public class ListItem
	{
		public string Title { get; set; }
		public string Description { get; set; }
	}

}


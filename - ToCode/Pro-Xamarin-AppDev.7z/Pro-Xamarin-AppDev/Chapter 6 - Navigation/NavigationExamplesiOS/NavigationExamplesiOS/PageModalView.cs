using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace NavigationExamplesiOS
{
	partial class PageModalView : UIView
	{
		public PageModalView (IntPtr handle) : base (handle)
		{
		}
	}
}

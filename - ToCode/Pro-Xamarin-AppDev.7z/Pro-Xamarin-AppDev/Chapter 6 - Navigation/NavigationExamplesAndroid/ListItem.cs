﻿using System;

namespace NavigationExamplesAndroid
{
	public class ListItem
	{
		public string Title { get; set; }
		public Type PageType { get; set; }
	}

}


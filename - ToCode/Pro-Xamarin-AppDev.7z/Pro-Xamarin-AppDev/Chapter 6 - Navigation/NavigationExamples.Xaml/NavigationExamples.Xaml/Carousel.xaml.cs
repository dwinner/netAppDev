﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NavigationExamples
{
	public partial class Carousel : CarouselPage
	{
		public Carousel ()
		{
			InitializeComponent ();
		}
	}
}


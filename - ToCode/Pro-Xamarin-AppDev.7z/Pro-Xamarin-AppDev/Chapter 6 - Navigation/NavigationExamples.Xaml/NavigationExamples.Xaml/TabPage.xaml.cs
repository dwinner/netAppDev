﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NavigationExamples
{
	public partial class TabPage : TabbedPage
	{
		public TabPage ()
		{
			InitializeComponent ();
		}
	}
}


﻿using System;
using Xamarin.Forms;

namespace NavigationExamples
{
    public class App : Application
    {
        public App()
        {
            MainPage = new NavigationDrawer(); 
        }
    }
}


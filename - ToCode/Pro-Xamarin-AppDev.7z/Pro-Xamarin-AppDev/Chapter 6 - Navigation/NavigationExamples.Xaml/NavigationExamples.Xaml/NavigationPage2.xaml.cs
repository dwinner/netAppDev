﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NavigationExamples
{
	public partial class NavigationPage2 : ContentPage
	{
		public NavigationPage2 ()
		{
			InitializeComponent ();
		}
	}
}


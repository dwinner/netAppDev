﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NavigationExamples
{
	public partial class ThirdPage : ContentPage
	{
		public ThirdPage ()
		{
			InitializeComponent ();
		}
	}
}


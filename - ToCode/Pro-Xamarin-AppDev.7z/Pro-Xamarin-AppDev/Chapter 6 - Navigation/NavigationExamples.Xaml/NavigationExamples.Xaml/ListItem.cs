﻿using System;
using Xamarin.Forms;

namespace NavigationExamples
{
    public class ListItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }

}

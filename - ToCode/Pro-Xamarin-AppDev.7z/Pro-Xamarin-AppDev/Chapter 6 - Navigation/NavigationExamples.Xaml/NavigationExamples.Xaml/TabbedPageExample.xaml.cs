﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace NavigationExamples
{	
	public partial class TabbedPageExample : TabbedPage
	{	
        public TabbedPageExample ()
        {
        //    this.Title = "TabbedPage";

        //    this.ItemsSource = new NamedColor[] 
        //    {
        //        new NamedColor("Red", Color.Red),
        //        new NamedColor("Yellow", Color.Yellow),
        //        new NamedColor("Green", Color.Green),
        //        new NamedColor("Aqua", Color.Aqua),
        //        new NamedColor("Blue", Color.Blue),
        //        new NamedColor("Purple", Color.Purple)
        //    };

        //    this.ItemTemplate = new DataTemplate(() => 
        //        { 
        //            return new NamedColorPage(false); 
        //        });
        }
	}
}


﻿using System;

namespace SQLiteNetPCL
{
	public interface IObject 
	{
		int ID { get; set; }
	}

}


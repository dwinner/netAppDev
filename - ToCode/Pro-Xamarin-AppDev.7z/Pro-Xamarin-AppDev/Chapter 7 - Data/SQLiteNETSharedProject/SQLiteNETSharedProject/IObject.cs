﻿using System;

namespace SQLiteNETSharedProject
{
	public interface IObject 
	{
		int ID { get; set; }
	}

}


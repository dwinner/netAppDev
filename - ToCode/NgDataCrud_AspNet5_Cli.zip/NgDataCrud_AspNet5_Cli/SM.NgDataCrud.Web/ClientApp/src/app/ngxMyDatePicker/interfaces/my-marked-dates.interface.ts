import { IMyDate } from "./my-date.interface";

export interface IMyMarkedDates {
    dates: Array<IMyDate>;
    color: string;
}

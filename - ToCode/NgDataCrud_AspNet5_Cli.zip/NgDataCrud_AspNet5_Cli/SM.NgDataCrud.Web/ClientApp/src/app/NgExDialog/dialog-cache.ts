﻿export class DialogCache {
    //Global cached variables.
    static noDrag: boolean = false;    
}

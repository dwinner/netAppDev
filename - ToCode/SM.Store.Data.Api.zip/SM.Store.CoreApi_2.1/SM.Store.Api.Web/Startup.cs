﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Diagnostics;
using Newtonsoft.Json.Serialization;
using Serilog;
using SM.Store.Api.DAL;
using SM.Store.Api.BLL;
using SM.Store.Api.Common;
using SM.Store.Api.Contracts.Configurations;
using SM.Store.Api.Contracts.Interfaces;

namespace SM.Store.Api.Web
{
    public class Startup
    {
        readonly IHostingEnvironment HostingEnvironment;
        public IConfigurationRoot Configuration { get; }

        public Startup(IHostingEnvironment env)
        {
            HostingEnvironment = env;

            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();

            Configuration = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //test
            //var ta = StaticConfigs.GetConfig("TestConfig1");
            var testValue = StaticConfigs.GetAppSetting("TestWebConfig");

            //Also make top level configuration available (for EF configuration and access to connection string)
            services.AddSingleton(Configuration); //IConfigurationRoot
            services.AddSingleton<IConfiguration>(Configuration);

            //Add Support for strongly typed Configuration and map to class
            services.AddOptions();
            services.Configure<AppConfig>(Configuration.GetSection("AppConfig"));

            //Set database.
            if (Configuration["AppConfig:UseInMemoryDatabase"] == "true")
            {
                services.AddDbContext<StoreDataContext>(opt => opt.UseInMemoryDatabase("StoreDbMemory"));
            }
            else
            {
                services.AddDbContext<StoreDataContext>(c =>
                    c.UseSqlServer(Configuration.GetConnectionString("StoreDbConnection")));
            }

            //Cors policy is added to controllers via [EnableCors("CorsPolicy")]
            //or .UseCors("CorsPolicy") globally
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials());
            });

            //Instance injection
            services.AddScoped(typeof(IAutoMapConverter<,>), typeof(AutoMapConverter<,>));
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
            services.AddScoped(typeof(IStoreLookupRepository<>), typeof(StoreLookupRepository<>));
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IContactRepository, ContactRepository>();
            services.AddScoped<ILookupBS, LookupBS>();
            services.AddScoped<IProductBS, ProductBS>();
            services.AddScoped<IContactBS, ContactBS>();

            ////Per request injections
            //services.AddScoped<ApiExceptionFilter>();

            //Add framework services
            services.AddMvc(options =>
            {
                //options.Filters.Add(new ApiExceptionFilter());                
            })
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
            .AddJsonOptions(opt =>
            {
                var resolver = opt.SerializerSettings.ContractResolver;
                if (resolver != null)
                {
                    var res = resolver as DefaultContractResolver;
                    res.NamingStrategy = null;
                }
            });
        }

        //This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app,
            IHostingEnvironment env,
            ILoggerFactory loggerFactory,
            IConfiguration configuration)
        {
            // Serilog config
            Log.Logger = new LoggerConfiguration()
                    .WriteTo.RollingFile(pathFormat: "logs\\log-{Date}.log")
                    .CreateLogger();

            if (env.IsDevelopment())
            {
                loggerFactory
                    .AddDebug()
                    .AddConsole()
                    .AddSerilog();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                loggerFactory
                    .AddSerilog();
                app.UseExceptionHandler(errorApp =>

                    //Application level exception handler here - this is just a place holder
                    errorApp.Run(async (context) =>
                    {
                        context.Response.StatusCode = 500;
                        context.Response.ContentType = "text/html";
                        await context.Response.WriteAsync("<html><body>\r\n");
                        await context.Response.WriteAsync(
                                "We're sorry, we encountered an un-expected issue with your application.<br>\r\n");

                        //Capture the exception
                        var error = context.Features.Get<IExceptionHandlerFeature>();
                        if (error != null)
                        {
                            //This error would not normally be exposed to the client
                            await context.Response.WriteAsync("<br>Error: " +
                                    HtmlEncoder.Default.Encode(error.Error.Message) + "<br>\r\n");
                        }
                        await context.Response.WriteAsync("<br><a href=\"/\">Home</a><br>\r\n");
                        await context.Response.WriteAsync("</body></html>\r\n");
                        await context.Response.WriteAsync(new string(' ', 512)); // Padding for IE
                    }));
            }
            //Console.WriteLine("\r\nPlatform: " + System.Runtime.InteropServices.RuntimeInformation.OSDescription);
            //Console.WriteLine("DB Connection: "  + Configuration.GetConnectionString("StoreDbConnection"));

            //app.UseAuthentication();
            app.UseDatabaseErrorPage();
            app.UseStatusCodePages();
            app.UseStaticFiles();

            //index.html is not required
            //app.UseDefaultFiles();

            //Apply CORS.
            app.UseCors("CorsPolicy");

            //put last so header configs like CORS or Cookies etc can fire
            app.UseMvcWithDefaultRoute();
        }
    }
}

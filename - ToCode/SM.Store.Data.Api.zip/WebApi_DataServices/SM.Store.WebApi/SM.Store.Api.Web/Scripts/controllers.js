﻿'use strict';
angular.module('smApp.controllers', function () {})

.controller('productListController', ['$scope', 'productList', 'productList_p', 'productObj', function ($scope, productList, productList_p, productObj) {
    $scope.model = {};
    $scope.model.productList = [];
    $scope.pSearchText = "";
    
    ////Get productList with input of query string.
    ////var input = 'ProductSearchField=CategoryId&ProductSearchText=3&PageIndex=0&PageSize=5&SortBy=ProductName&SortDirection=ascending'
    //var input = 'ProductSearchField=&ProductSearchText=&PageIndex=0&PageSize=100&SortBy=CategoryId&SortDirection=ascending';
    //productList.query({ params: input }, function (data) {
    //    $scope.model.productList = data.Products;
    //    $scope.model.totalCount = data.TotalCount;
    //}
    ////, function (error) {
    ////    alert(error.data);        
    ////}
    //);
    
    //Get productList with Post and input of JSON string.
    var inputJson = "{\"ProductSearchFilter\": {\"ProductSearchField\": \"CategoryId\",\"ProductSearchText\": \"3\"}, \"PaginationRequest\": {\"PageIndex\": 0,\"PageSize\": 5,\"Sort\": {\"SortBy\": \"\",\"SortDirection\": 0}}}";
    productList_p.post(inputJson, function (data) {
        $scope.model.productList = data.Products;
        $scope.model.totalCount = data.TotalCount;        
    }, function (error) {
        alert(error.data);
    });
       
    $scope.pSearchText = "";
    $scope.getProduct = function () {
        productObj.query({ id: $scope.pSearchText }, function (data) {
            $scope.model.product = data;
        }, function (error) {
            alert(error.data);
        });
    };    
}])
;



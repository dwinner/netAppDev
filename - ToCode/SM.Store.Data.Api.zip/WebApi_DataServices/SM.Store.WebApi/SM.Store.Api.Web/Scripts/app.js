﻿'use strict'

//Declare app level module which depends on filters, and services
angular.module('smApp', ['ngRoute', 'smApp.controllers', 'smApp.dataServices', function () {
}])
//Configure the routes
.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
    .when('/main', {
        templateUrl: '/Pages/loadProducts.html',
        controller: 'productListController'
    })    
    ;
    $routeProvider.otherwise({ redirectTo: '/main' });
}])

.config(["$provide", function ($provide) {    
    $provide.decorator("$exceptionHandler", ["$delegate", function ($delegate) {
        return function (exception, cause) {
            exception.message += ' (caused by "' + cause + '")';
            alert(exception.message);
            //$delegate(exception, cause);
        }        
    }]);
}])
;


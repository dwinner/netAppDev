﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SM.Store.Api.Models
{
   public class SearchFilter
    {
        public string SearchType { get; set; }
        public string SearchText { get; set; }
    }
}

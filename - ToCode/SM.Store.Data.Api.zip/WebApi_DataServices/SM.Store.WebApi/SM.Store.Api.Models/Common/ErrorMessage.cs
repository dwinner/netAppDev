
namespace SM.Store.Api.Models
{
    using System;
    
    public class ErrorMessage
    {
        public string Code { get; set; }
        public string Message { get; set; }
               
    }

}

﻿
namespace SM.Store.Api.Models
{
    using System;

    public class BaseResponse
    {
        public Status Status { get; set; }
    }

}

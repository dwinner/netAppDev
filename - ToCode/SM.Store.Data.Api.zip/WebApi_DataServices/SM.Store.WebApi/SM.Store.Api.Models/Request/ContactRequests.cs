﻿using System;
using System.Collections.Generic;

namespace SM.Store.Api.Models
{
    public class ContactRequests
    {
        
    }

    public class SaveContactRequest
    {
        public Contact Contact { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SM.Store.Api.Common
{
    public class Constants
    {        
        public const string GLOBAL_NAMESPACE = "http://www.ugiu.com/services/StoreData";
        public const string LAST_CHANGED_TIME_PROPERTY_NAME = "AuditTime";        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using SM.Store.Api.Common;
using SM.Store.Api.Contracts.TestModels;

namespace SM.Store.Api.Controllers
{
    [Route("api/[controller]")]
    public class TestModelBinderController : Controller
    {
        [Route("~/api/nvpstonestget")]
        public NestSearchRequest Get_NvpsToNest([ModelBinder(typeof(FieldValueModelBinder))] NestSearchRequest request)
        {
            return request;
        }
        //[Route("~/api/nvpstonestget")]
        //public NestSearchRequest Get_NvpsToNest([FromUri] NestSearchRequest request)
        //{
        //    return request;
        //}

        [Route("~/api/nvpstonestpost")]
        public NestSearchRequest Post_NvpsToNest([ModelBinder(typeof(FieldValueModelBinder))] NestSearchRequest request)
        {
            return request;
        }
                
        [Route("~/api/nvpstonestcollectionget")]
        public ComplexSearchRequest Get_NvpsToNestCollection([ModelBinder(typeof(FieldValueModelBinder))] ComplexSearchRequest request)
        {
            return request;
        }

        [Route("~/api/stringlistorarrayget")]
        public PagingSortRequest2 Get_StringListOrArray([ModelBinder(typeof(FieldValueModelBinder))] PagingSortRequest2 request)
        {
            return request;
        }

        //Used for testing passing json object.
        [Route("~/api/stringlistorarraypost")]
        public PagingSortRequest2 Post_StringListOrArray([ModelBinder(typeof(FieldValueModelBinder))] PagingSortRequest2 request)
        {
            return request;
        } 
    }
}

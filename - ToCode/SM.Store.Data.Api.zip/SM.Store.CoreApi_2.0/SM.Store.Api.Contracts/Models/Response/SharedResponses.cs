﻿
namespace SM.Store.Api.Contracts.Models
{
    using System;

    public class ReturnNumber
    {
        public int NumberValue { get; set; }
    }

    public class ReturnString
    {
        public string StringValue { get; set; }
    } 
}

﻿using System;
using System.Collections.Generic;

namespace SM.Store.Api.Contracts.Models
{
    public class ContactRequests
    {
        
    }

    public class SaveContactRequest
    {
        public Contact Contact { get; set; }
    }
}
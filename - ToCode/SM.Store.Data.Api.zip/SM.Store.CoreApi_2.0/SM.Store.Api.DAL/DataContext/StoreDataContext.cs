﻿using Microsoft.EntityFrameworkCore;
using SM.Store.Api.Contracts.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SM.Store.Api.DAL
{
    public class StoreDataContext : DbContext
    {
        //public string ConnectionString { get; set; }

        public StoreDataContext(DbContextOptions<StoreDataContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<ProductStatusType> ProductStatusTypes { get; set; }
        public DbSet<Contact> Contacts { get; set; }


        protected override void OnModelCreating(ModelBuilder builder)
        {
            //base.OnModelCreating(builder);
            builder.Entity<Product>().ToTable("Product");
            builder.Entity<Category>().ToTable("Category");
            builder.Entity<ProductStatusType>().ToTable("ProductStatusType");
            builder.Entity<Contact>().ToTable("Contact");
        }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    //base.OnConfiguring(optionsBuilder);

        //    //if (optionsBuilder.IsConfigured)
        //    //    return;

        //    //ConnectionString = Configuration.GetValue<string>("ConnectionStrings:StoreDbConnection");
        //    ConnectionString = "Server=(localdb)\\SQLLocal2016; Integrated Security = true; Initial Catalog = StoreCF7;";
        //    optionsBuilder.UseSqlServer(ConnectionString);
        //}

    }
}
import { Directive, HostListener, ElementRef, Renderer, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgExDialogConfig } from './dialog-config';

@Directive({
    selector: '[vertical-center]'
})
export class VerticalCenterDirective implements OnInit {

    constructor(private element: ElementRef, private renderer: Renderer, private ngExDialogConfig: NgExDialogConfig) {
    }

    //Passed from parent view. x?
    dialogPaddingTop: number = 0;
    isPrimeType: boolean;

    ngOnInit() {
        //Initial load need a little top offset.
        this.SetCenter(undefined, true);
    }

    @HostListener('window:resize', ['$event'])
    onResize(event: any) {
        this.SetCenter(event);
    }

    SetCenter(event?: any, isInit?: boolean) {
        let eventTarget = event == undefined ? window : event.target;
        let wh = eventTarget.innerHeight;
        let sy = eventTarget.scrollY;      //Top invisible height when scroll down.
        let ot = this.element.nativeElement.offsetTop;
        let ch = this.element.nativeElement.offsetHeight - this.dialogPaddingTop; //Dialog visible height

        //IE doesn't support scrollY but it automatically scrolls back to the top 0 position.
        //The scrollY needs to be added for Google Chrome, Firefox, and Microsoft Edge.
        //let paddingTopValue = (wh - ch) / 2 + (sy == undefined ? 0 : sy) - DialogConfig.topOffset; 

        //For most dynamic filled content, offsetHeight is very small.
        if (this.isPrimeType) {
            if (ch < 350) {
                ch = 350;
            }
        }     
        let paddingTopValue = (wh - ch) / 2; //- this.ngExDialogConfig.merged.topOffset;  

        if (paddingTopValue < 0) {
            paddingTopValue = 0;
        }
        else {
            //For most dynamic filled content, offsetHeight is very small.Need to adjust padding-top.
            if (this.isPrimeType) {
                if (paddingTopValue > 30) {
                    paddingTopValue = 30;
                }
            }
            else {
                paddingTopValue = paddingTopValue - this.ngExDialogConfig.merged.topOffset;
            }            
        }        
        
        //Cache dialogPaddingTop value for use in next resize.
        this.dialogPaddingTop = paddingTopValue;

        if (isInit) {
            paddingTopValue = paddingTopValue - this.ngExDialogConfig.merged.topOffset / 1.5;
        }

        this.renderer.setElementStyle(this.element.nativeElement, 'padding-top', paddingTopValue + 'px');

        this.renderer.setElementStyle(this.element.nativeElement, 'margin-right', 'auto');
        this.renderer.setElementStyle(this.element.nativeElement, 'margin-left', 'auto');
    }
}
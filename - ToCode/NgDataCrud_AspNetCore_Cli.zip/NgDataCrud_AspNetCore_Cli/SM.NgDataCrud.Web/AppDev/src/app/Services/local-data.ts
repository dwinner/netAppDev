export const ProductSearchTypes: Array<any> = [
    //{ id: "", name: "Please select..." },
    { id: "CategoryId", name: "Category ID" },
    { id: "CategoryName", name: "Category Name" },
    { id: "ProductId", name: "Product ID" },
    { id: "ProductName", name: "Product Name" }
];

export const ProductStautsTypes: Array<any> = [
    //{ StatusCode: "", Description: "Please select..." },
    { StatusCode: "1", Description: "Available" },
    { StatusCode: "2", Description: "Out of Stock" },
    { StatusCode: "3", Description: "Back Ordered" },
    { StatusCode: "4", Description: "Discontinued" },
    { StatusCode: "5", Description: "Undefined" }
];

export const PrimaryContactTypes: Array<any> = [
    { id: 0, name: "Please select..." },
    { id: 1, name: "Phone" },
    { id: 2, name: "Email" }
];

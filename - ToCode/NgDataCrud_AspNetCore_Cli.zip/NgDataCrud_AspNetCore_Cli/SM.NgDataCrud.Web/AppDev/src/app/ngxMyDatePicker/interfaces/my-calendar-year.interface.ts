export interface IMyCalendarYear {
    year: number;
    currYear: boolean;
    selected: boolean;
    disabled: boolean;
}
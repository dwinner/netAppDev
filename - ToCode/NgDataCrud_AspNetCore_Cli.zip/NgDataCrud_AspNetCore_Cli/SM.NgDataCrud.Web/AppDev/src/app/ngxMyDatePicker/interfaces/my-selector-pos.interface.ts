export interface IMySelectorPosition {
    top: string;
    left: string;
}
export interface IMyMonth {
    monthTxt: string;
    monthNbr: number;
    year: number;
}
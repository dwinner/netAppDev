import {
    Directive, ElementRef, Renderer, EventEmitter, Input, Output, HostListener, OnInit, AfterViewInit, Inject
} from '@angular/core';
import { TableMainDirective } from './table-main.directive';
import { PagingParams } from './model-interface';
import { NgExTableConfig } from './ngex-table.config';
import { TableChange } from './constants';

@Directive({
    selector: '[sortBy]'
})
export class TableSortingDirective implements OnInit {
    config: any;
    @Input('sortBy') sortBy: string;
    @Output() sortChanged: EventEmitter<PagingParams> = new EventEmitter<PagingParams>();

    sortDirection: string = "";
    toggleWithOriginalDataOrder: boolean;

    constructor(private element: ElementRef, private renderer: Renderer,
        private tableParamsDirective: TableMainDirective, private ngExTableConfig: NgExTableConfig) {
    }

    ngOnInit(): void {
        this.config = this.ngExTableConfig.main;

        if (this.config.toggleWithOriginalDataOrder !== undefined) {
            this.toggleWithOriginalDataOrder = this.config.toggleWithOriginalDataOrder;
        }
    }

    ngAfterViewInit() {
        this.renderer.setElementClass(this.element.nativeElement, "cursor-pointer", true);
        //Not working.
        //let insertedHtml = "<div *ngIf='this.sortBy !== undefined' class='fa'" +
        //"[ngClass] = \"{'fa-chevron-down': sortDirection === 'desc', 'fa-chevron-up': sortDirection === 'asc'}\" ></div>";

        let sortingIconCssLib = this.config.sortingIconCssLib;
        let sortingIconColor = this.config.sortingIconColor;
        let insertedHtml: string = "<div class='{css0} {ccs1}' style='color: {color};'></div>";

        insertedHtml = insertedHtml.replace("{css0}", sortingIconCssLib).replace("{color}", sortingIconColor);
        if (this.config.sortingIconLocation == "label-right") {
            insertedHtml = "&#160;" + insertedHtml.replace("{ccs1}", "");            
        }
        else if (this.config.sortingIconLocation == "column-right") {
            insertedHtml = insertedHtml.replace("{ccs1}", "float-pad-right");            
        }        
        this.element.nativeElement.insertAdjacentHTML('beforeend', insertedHtml);

        this.sortDirection = this.tableParamsDirective.pagingParams.sortDirection;
        this.setSortingIcons(this.sortDirection);        
    }

    @HostListener('click', ['$event'])
    onToggleSort(event:any):void {        
                
        let tp = this.tableParamsDirective.pagingParams;
        let params: PagingParams = {
            pageNumber: tp.pageNumber,
            pageSize: tp.pageSize,
            sortBy: this.sortBy,
            sortDirection: this.sortDirection,
            changeType: TableChange.sorting
        };        

        if (event) {
            event.preventDefault();
        }

        if (tp.sortBy == this.sortBy) {
            switch (tp.sortDirection) {
                case "asc":
                    params.sortDirection = "desc";
                    break;
                case "desc":
                    params.sortDirection = this.toggleWithOriginalDataOrder ? "" : "asc";
                    break;
                default:
                    params.sortDirection = "asc";
                    break;
            }
        }
        else {
            params.sortDirection = "asc";
        }
        //Set sorting icons.
        this.setSortingIcons(params.sortDirection, true);

        this.sortDirection = params.sortDirection;
        this.tableParamsDirective.sortChanged(params);        
    }

    setSortingIcons(sortDirection: string, clearOthers: boolean = false) {        
        //Get font icon values from config.
        let ascIcon = this.config.sortingAscIcon;
        let descIcon = this.config.sortingDescIcon;
        let baseIcon = this.config.sortingBaseIcon;

        if (clearOthers) {
            //Clear any icon that is not linked to this element.
            let thElems = this.element.nativeElement.parentElement.getElementsByTagName("th");
            let thList = Array.prototype.slice.call(thElems);
            thList.forEach((th: any) => {
                if (th !== this.element.nativeElement && th.firstElementChild) {
                    this.renderer.setElementClass(th.firstElementChild, ascIcon, false);
                    this.renderer.setElementClass(th.firstElementChild, descIcon, false);
                    if (baseIcon && baseIcon != "")
                        this.renderer.setElementClass(th.firstElementChild, baseIcon, true);
                }
            });
        }

        //Set icons.
        if (sortDirection == "asc") {
            this.renderer.setElementClass(this.element.nativeElement.firstElementChild, ascIcon, true);
            this.renderer.setElementClass(this.element.nativeElement.firstElementChild, descIcon, false); 
            if (baseIcon && baseIcon != "")
                this.renderer.setElementClass(this.element.nativeElement.firstElementChild, baseIcon, false);
        }
        else if (sortDirection == "desc") {
            this.renderer.setElementClass(this.element.nativeElement.firstElementChild, ascIcon, false);
            this.renderer.setElementClass(this.element.nativeElement.firstElementChild, descIcon, true);
        }
        else {
            ;
            this.renderer.setElementClass(this.element.nativeElement.firstElementChild, descIcon, false);
            if (baseIcon && baseIcon != "")
                this.renderer.setElementClass(this.element.nativeElement.firstElementChild, baseIcon, true);
        }
    }
}

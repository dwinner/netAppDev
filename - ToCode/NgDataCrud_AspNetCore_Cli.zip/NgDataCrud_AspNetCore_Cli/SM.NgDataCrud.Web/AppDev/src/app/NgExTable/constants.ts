
export const enum TableChange {
    init,
    search,
    pageNumber,
    pageSize,
    sorting
}


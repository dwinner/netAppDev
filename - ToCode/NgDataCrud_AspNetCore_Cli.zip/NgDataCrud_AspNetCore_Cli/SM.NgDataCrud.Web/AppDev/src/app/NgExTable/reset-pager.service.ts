﻿import { Injectable } from '@angular/core';
import { PagingParams, ParamsToUpdatePager } from './model-interface';
import { NgExTableConfig } from './ngex-table.config';
import { TableChange } from './constants';
import { Subject } from 'rxjs';

@Injectable()
export class ResetPagerService {
    config: any;

    //For calling component.
    private tableMainDirective = new Subject<any>();
    tableMainDirective$ = this.tableMainDirective.asObservable();

    private paginationComponent = new Subject<any>();
    paginationComponent$ = this.paginationComponent.asObservable();
    

    constructor(ngExTableConfig: NgExTableConfig) {
        this.config = ngExTableConfig.main;
    }

    //Method called from table-hosting component before data retrieval.
    setPagingParamsBeforeData(pagingParams: PagingParams) {
        if (pagingParams.changeType == TableChange.search) {
            //Reset sorting parameters and icons if necessary.
            this.resetParamsForSearch(pagingParams);
        }
        else {
            //For sorting change, set pageNumber based on config.
            if (pagingParams.changeType == TableChange.sorting) {
                this.resetParamsForSorting(pagingParams);
            }
        }        
    } 

    //Method called from table-hosting component after obtaining data.
    updatePagerAfterData(pagingParams: PagingParams, totalLength: number) {        
        if (pagingParams.changeType == TableChange.search) {
            //Data items can only fit page 1.
            if (totalLength && (totalLength <= pagingParams.pageSize && pagingParams.pageNumber != 1)) {
                pagingParams.pageNumber = 1;
            }
            //Call PaginationComponent to set changeType and run selectPage method.
            this.updatePagerForChangeType(TableChange.search, pagingParams.pageNumber);
        }
        else {
            //For sorting change, set pageNumber based on config.
            if (pagingParams.changeType == TableChange.sorting) {
                this.updatePagerForChangeType(TableChange.sorting, pagingParams.pageNumber);               
            }

            //For pagesize change.
            if (pagingParams.changeType == TableChange.pageSize) {
                this.updatePagerForPageSize(pagingParams.pageNumber);
            }
        }
    }

    resetParamsForSearch(pagingParams: PagingParams) {
        //Set pageNumber based on config.
        if (this.config.pageNumberWhenSearchChange != -1) {
            pagingParams.pageNumber = this.config.pageNumberWhenSearchChange;
        }

        if (this.config.sortingWhenSearchChange != "current") {
            pagingParams.sortBy = "";
            pagingParams.sortDirection = "";

            //Call tableMainDirective method setBaseSortingIcons().
            this.tableMainDirective.next("setBaseSortingIcons");
        }
    }
        
    resetParamsForSorting(pagingParams: PagingParams) {
        //Set pageNumber based on config.
        if (this.config.pageNumberWhenSortingChange != -1) {
            pagingParams.pageNumber = this.config.pageNumberWhenSortingChange;
        }        
    }    
        
    updatePagerForPageSize(pageNumber: number) {
        //Set sorting icon based on config.
        if (this.config.sortingWhenPageSizeChange != "current") {
            //Call tableMainDirective method setBaseSortingIcons().
            this.tableMainDirective.next("setBaseSortingIcons");
        }

        //Update pager - call PaginationComponent.setPagerForSizeChange().
        this.updatePagerForChangeType(TableChange.pageSize, pageNumber);
    }

    //Generic method.
    updatePagerForChangeType(changeType: TableChange, pageNumber: number) {
        //Call PaginationComponent to set changeType and run selectPage method.
        let paramesToUpdatePager: ParamsToUpdatePager = {
            changeType: changeType,
            pageNumber: pageNumber
        };
        this.paginationComponent.next(paramesToUpdatePager);
    }
}
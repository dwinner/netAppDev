import { TableChange } from './constants';

export interface PagingParams {
    pageSize: number;
    pageNumber: number;
    sortBy: string;
    sortDirection: string; //asc; desc;
    changeType: any;
}

export interface ClientPaginationOutput {
    pagingParams: PagingParams;
    dataList: Array<any>;        
}

export interface NameValueItem {
    name: string;
    value: string;
}

export interface ChangeWith {
    pageNumber: number;
    pageSize: number;
    sorting: number;
}

export interface ParamsToUpdatePager {    
    changeType: TableChange;
    pageNumber: number;
}


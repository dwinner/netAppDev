﻿import { Injectable } from '@angular/core';
import { PagingParams, ClientPaginationOutput } from './model-interface';
import { NgExTableConfig } from './ngex-table.config';

@Injectable()
export class ClientPaginationService {
    config: any;
    constructor(ngExTableConfig: NgExTableConfig) {
        this.config = ngExTableConfig.main;
    }

    processData(pagingParams: PagingParams, dataList: Array<any>): ClientPaginationOutput {
        let sortedData: Array<any>;
        let dataListClone: Array<any>;

        //Keep passed dataList unchanged after sorting.
        dataListClone = Object.assign([], dataList);
        
        let output: ClientPaginationOutput = {
            pagingParams: {
                pageSize: pagingParams.pageSize,
                pageNumber: pagingParams.pageNumber,
                sortBy: pagingParams.sortBy,
                sortDirection: pagingParams.sortDirection,
                changeType: pagingParams.changeType
            },
            dataList: []
        };  
        if (pagingParams) {
            if (pagingParams.sortBy == "" && pagingParams.sortDirection == "") {
                //Initial.
                sortedData = dataList;
            }
            else if (pagingParams.sortBy != "" && pagingParams.sortDirection != "") {
                sortedData = this.changeSort(pagingParams, dataListClone);
            }
            else if (pagingParams.sortBy != "" && pagingParams.sortDirection == "") {
                if (this.config.toggleWithOriginalDataOrder) {
                    sortedData = dataList;
                }
            }
            output = this.getPagedData(pagingParams, sortedData);

            //Return refreshed pagingParams.
            output.pagingParams.sortBy = pagingParams.sortBy;
            output.pagingParams.sortDirection = pagingParams.sortDirection;
            
            return output;
        }
    }

    //Sorting logic.
    changeSort(pagingParams: PagingParams, data: Array<any>): Array<any> {
        if (!pagingParams.sortBy) {
            return data;
        }        
        return data.sort((previous: any, current: any) => {
            //Null is sorted to the last for both asc and desc.
            if (previous[pagingParams.sortBy] === null)
                return 1;
            else if (current[pagingParams.sortBy] === null)
                return -1;
            else if (previous[pagingParams.sortBy] > current[pagingParams.sortBy]) {
                return pagingParams.sortDirection === 'desc' ? -1 : 1;
            } else if (previous[pagingParams.sortBy] < current[pagingParams.sortBy]) {
                return pagingParams.sortDirection === 'asc' ? -1 : 1;
            }
            return 0;
        });
    }

    getPagedData(pagingParams: PagingParams, sortedData: Array<any>): ClientPaginationOutput {
        let pagedData: Array<any>;
        let output: ClientPaginationOutput = {
            pagingParams: {
                pageSize: pagingParams.pageSize,
                pageNumber: pagingParams.pageNumber,
                sortBy: pagingParams.sortBy,
                sortDirection: pagingParams.sortDirection,
                changeType: pagingParams.changeType 
            },
            dataList: []
        };

        if (!sortedData) {
            return output;
        }

        if (pagingParams && pagingParams.pageNumber && pagingParams.pageSize) {            

            //Handle pageNumber no available for data length.
            let allowedPageNumber: number = Math.ceil(sortedData.length / pagingParams.pageSize);
            if (allowedPageNumber < pagingParams.pageNumber) {
                pagingParams.pageNumber = allowedPageNumber;
            }
            let start = (pagingParams.pageNumber - 1) * pagingParams.pageSize;
            let end = pagingParams.pageSize > -1 ? (start + pagingParams.pageSize) : sortedData.length;
            output.dataList = sortedData.slice(start, end);

            //Return refreshed pagingParams.
            output.pagingParams.pageNumber = pagingParams.pageNumber;
            output.pagingParams.pageSize = pagingParams.pageSize;
        }
        else {
            output.dataList = sortedData;
        } 
        return output;
    }
}
import { NgModule, ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TableMainDirective } from './table-main.directive';
import { TableSortingDirective } from './table-sorting.directive';
import { NgExTableConfig } from './ngex-table.config';
import { PaginationComponent } from './pagination.component';
import { ResetPagerService } from './reset-pager.service';
import { ClientPaginationService } from './client-pagination.service';

@NgModule({    
    declarations: [
        TableMainDirective,
        TableSortingDirective,
        PaginationComponent
    ],
    providers: [
        NgExTableConfig,
        ResetPagerService,
        ClientPaginationService
    ],
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule
    ],
    exports: [
        TableMainDirective,
        TableSortingDirective,
        PaginationComponent
    ],
    entryComponents: [
        PaginationComponent        
    ]
})
export class NgExTableModule {
    //static forRoot(): ModuleWithProviders {
    //    return { ngModule: NgExTableModule, providers: [ClientPaginationService] };
    //}
}

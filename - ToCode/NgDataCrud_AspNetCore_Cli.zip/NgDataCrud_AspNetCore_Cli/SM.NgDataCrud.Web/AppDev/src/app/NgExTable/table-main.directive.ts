import { Directive, Input, EventEmitter, SimpleChange, OnInit, OnChanges, Output, ElementRef, Renderer} from "@angular/core";
import { PagingParams } from './model-interface';
import { NgExTableConfig } from './ngex-table.config';
import { ResetPagerService } from './reset-pager.service';

@Directive({
    selector: 'table[params]',
    exportAs: 'ngExTable'
})
export class TableMainDirective implements OnInit {
    config: any;
    @Input("params") pagingParams: PagingParams;
    
    @Output() tableChanged: EventEmitter<PagingParams> = new EventEmitter<PagingParams>();

    constructor(private element: ElementRef, private renderer: Renderer, private ngExTableConfig: NgExTableConfig, private resetPagerService: ResetPagerService) {        
        //Called method from service.
        this.resetPagerService.tableMainDirective$.subscribe(
            (methodName: string) => {
                if (methodName == "setBaseSortingIcons") {
                    this.setBaseSortingIcons();
                }                
            }
        );
    }

    ngOnInit() {    
        this.config = this.ngExTableConfig.main;
    }

    //ngOnChanges(changes: { [key: string]: SimpleChange }): any {
    //    let tc = changes;
    //    let te = this.pagingParams;
    //}

    sortChanged(params: PagingParams) {
        this.tableChanged.emit(params);   
    }

    setBaseSortingIcons() {
        //Get font icon values from config.
        let ascIcon = this.config.sortingAscIcon;
        let descIcon = this.config.sortingDescIcon;
        let baseIcon = this.config.sortingBaseIcon;
        
        //Clear or set all column headers to base icon.
        let thElems = this.element.nativeElement.getElementsByTagName("th");
        let thList = Array.prototype.slice.call(thElems);
        thList.forEach((th: any) => {
            if (th.firstElementChild) {
                this.renderer.setElementClass(th.firstElementChild, ascIcon, false);
                this.renderer.setElementClass(th.firstElementChild, descIcon, false);
                if (baseIcon && baseIcon != "")
                    this.renderer.setElementClass(th.firstElementChild, baseIcon, true);
            }
        });
    }
}
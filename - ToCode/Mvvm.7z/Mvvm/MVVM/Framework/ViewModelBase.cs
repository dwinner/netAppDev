﻿namespace Framework
{
    public abstract class ViewModelBase : BindableBase
    {
    }
}

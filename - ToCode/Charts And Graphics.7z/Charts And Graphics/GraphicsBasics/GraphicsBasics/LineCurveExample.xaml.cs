
namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for LineCurveExample.xaml
   /// </summary>

   public partial class LineCurveExample : System.Windows.Window
   {

      public LineCurveExample()
      {
         InitializeComponent();
      }

   }
}
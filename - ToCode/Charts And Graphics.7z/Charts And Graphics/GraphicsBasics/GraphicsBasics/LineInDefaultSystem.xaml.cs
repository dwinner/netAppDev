﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for LineInDefaultSystem.xaml
   /// </summary>
   public partial class LineInDefaultSystem : Window
   {
      public LineInDefaultSystem()
      {
         InitializeComponent();
      }
   }
}

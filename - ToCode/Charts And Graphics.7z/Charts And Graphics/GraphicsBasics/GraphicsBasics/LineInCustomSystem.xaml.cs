﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for LineInCustomSystem.xaml
   /// </summary>
   public partial class LineInCustomSystem : Window
   {
      public LineInCustomSystem()
      {
         InitializeComponent();
      }
   }
}

using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for GeometryGroupExample.xaml
   /// </summary>

   public partial class AnimateBezierCurve : Window
   {
      public AnimateBezierCurve()
      {
         InitializeComponent();
      }
   }
}
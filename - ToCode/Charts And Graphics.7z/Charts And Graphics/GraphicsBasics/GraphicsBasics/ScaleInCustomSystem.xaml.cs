﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for ScaleInCustomSystem.xaml
   /// </summary>
   public partial class ScaleInCustomSystem : Window
   {
      public ScaleInCustomSystem()
      {
         InitializeComponent();
      }
   }
}

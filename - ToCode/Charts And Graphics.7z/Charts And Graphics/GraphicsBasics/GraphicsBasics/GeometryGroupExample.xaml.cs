
namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for GeometryGroupExample.xaml
   /// </summary>

   public partial class GeometryGroupExample : System.Windows.Window
   {

      public GeometryGroupExample()
      {
         InitializeComponent();
      }

   }
}
﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for PolygonFillRule.xaml
   /// </summary>
   public partial class PolygonFillRule : Window
   {
      public PolygonFillRule()
      {
         InitializeComponent();
      }
   }
}


namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for CombinedGeometryExample.xaml
   /// </summary>

   public partial class CombinedGeometryExample : System.Windows.Window
   {

      public CombinedGeometryExample()
      {
         InitializeComponent();
      }

   }
}
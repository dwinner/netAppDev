﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for PlaceShapes.xaml
   /// </summary>
   public partial class PlaceShapes : Window
   {
      public PlaceShapes()
      {
         InitializeComponent();
      }
   }
}

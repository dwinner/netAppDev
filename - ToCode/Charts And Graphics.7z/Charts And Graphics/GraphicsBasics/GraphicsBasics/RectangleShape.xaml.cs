﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for RectangleShape.xaml
   /// </summary>
   public partial class RectangleShape : Window
   {
      public RectangleShape()
      {
         InitializeComponent();
      }
   }
}

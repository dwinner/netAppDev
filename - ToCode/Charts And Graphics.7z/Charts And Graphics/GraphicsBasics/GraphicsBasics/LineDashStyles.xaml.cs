﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class LineDashStyles : Window
   {
      public LineDashStyles()
      {
         InitializeComponent();
      }
   }
}

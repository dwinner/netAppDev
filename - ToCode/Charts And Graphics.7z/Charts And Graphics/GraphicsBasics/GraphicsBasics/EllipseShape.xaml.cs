﻿using System.Windows;

namespace GraphicsBasics
{
   /// <summary>
   /// Interaction logic for EllipseShape.xaml
   /// </summary>
   public partial class EllipseShape : Window
   {
      public EllipseShape()
      {
         InitializeComponent();
      }
   }
}

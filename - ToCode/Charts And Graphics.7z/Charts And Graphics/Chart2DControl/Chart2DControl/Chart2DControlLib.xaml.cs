﻿using System.Windows.Controls;

namespace Chart2DControl
{
   /// <summary>
   /// Interaction logic for UserControl1.xaml
   /// </summary>
   public partial class Chart2DControlLib : UserControl
   {
      public Chart2DControlLib()
      {
         InitializeComponent();
      }
   }
}

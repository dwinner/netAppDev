﻿using System.Windows;

namespace WPFOverview
{
   /// <summary>
   /// Interaction logic for XAMLOnly.xaml
   /// </summary>
   public partial class XAMLOnly : Window
   {
      public XAMLOnly()
      {
         InitializeComponent();
      }
   }
}

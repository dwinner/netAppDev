﻿using System.Windows;

namespace Specialized2DChartControlTest
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {
   }
}

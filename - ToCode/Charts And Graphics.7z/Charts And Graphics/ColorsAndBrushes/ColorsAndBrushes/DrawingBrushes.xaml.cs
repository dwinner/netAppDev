using System.Windows;

namespace ColorsAndBrushes
{
   /// <summary>
   /// Interaction logic for DrawingBrushExample.xaml
   /// </summary>

   public partial class DrawingBrushes : Window
   {

      public DrawingBrushes()
      {
         InitializeComponent();
      }

   }
}

namespace ColorsAndBrushes
{
   /// <summary>
   /// Interaction logic for RadialGradientBrushExample.xaml
   /// </summary>

   public partial class RadialGradientBrushes : System.Windows.Window
   {

      public RadialGradientBrushes()
      {
         InitializeComponent();
      }

   }
}
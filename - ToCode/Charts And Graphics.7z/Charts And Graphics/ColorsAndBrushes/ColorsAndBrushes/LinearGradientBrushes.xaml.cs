
namespace ColorsAndBrushes
{
   /// <summary>
   /// Interaction logic for LinearGradientBrushExample.xaml
   /// </summary>

   public partial class LinearGradientBrushes : System.Windows.Window
   {

      public LinearGradientBrushes()
      {
         InitializeComponent();
      }

   }
}
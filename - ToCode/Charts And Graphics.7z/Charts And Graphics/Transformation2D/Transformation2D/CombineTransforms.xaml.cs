﻿using System.Windows;

namespace Transformation2D
{
   /// <summary>
   /// Interaction logic for CombineTransforms.xaml
   /// </summary>
   public partial class CombineTransforms : Window
   {
      public CombineTransforms()
      {
         InitializeComponent();
      }
   }
}

﻿using System.Windows;

namespace Transformation2D
{
   /// <summary>
   /// Interaction logic for RotateTransforms.xaml
   /// </summary>
   public partial class RotateTransforms : Window
   {
      public RotateTransforms()
      {
         InitializeComponent();
      }
   }
}

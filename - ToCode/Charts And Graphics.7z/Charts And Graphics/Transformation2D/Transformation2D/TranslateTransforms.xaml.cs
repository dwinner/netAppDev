﻿using System.Windows;

namespace Transformation2D
{
   /// <summary>
   /// Interaction logic for TranslateTransforms.xaml
   /// </summary>
   public partial class TranslateTransforms : Window
   {
      public TranslateTransforms()
      {
         InitializeComponent();
      }
   }
}

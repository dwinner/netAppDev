﻿using System.Windows;

namespace Transformation2D
{
   /// <summary>
   /// Interaction logic for ScaleTransforms.xaml
   /// </summary>
   public partial class ScaleTransforms : Window
   {
      public ScaleTransforms()
      {
         InitializeComponent();
      }
   }
}

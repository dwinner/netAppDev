﻿using System.Windows;

namespace Transformation2D
{
   /// <summary>
   /// Interaction logic for SKewTransforms.xaml
   /// </summary>
   public partial class SkewTransforms : Window
   {
      public SkewTransforms()
      {
         InitializeComponent();
      }
   }
}

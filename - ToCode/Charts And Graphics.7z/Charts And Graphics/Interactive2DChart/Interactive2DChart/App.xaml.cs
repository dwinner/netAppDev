﻿using System.Windows;

namespace Interactive2DChart
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {
   }
}

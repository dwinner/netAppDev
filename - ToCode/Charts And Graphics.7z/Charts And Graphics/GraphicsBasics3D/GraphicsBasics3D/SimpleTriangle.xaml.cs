﻿using System.Windows;

namespace GraphicsBasics3D
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class SimpleTriangle : Window
   {
      public SimpleTriangle()
      {
         InitializeComponent();
      }

      private void Window_Loaded(object sender, RoutedEventArgs e)
      {

      }
   }
}

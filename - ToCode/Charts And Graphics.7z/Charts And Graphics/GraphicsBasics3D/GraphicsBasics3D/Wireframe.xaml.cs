﻿using System.Windows;

namespace GraphicsBasics3D
{
   /// <summary>
   /// Interaction logic for Wireframe.xaml
   /// </summary>
   public partial class Wireframe : Window
   {
      public Wireframe()
      {
         InitializeComponent();
      }
   }
}

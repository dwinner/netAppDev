﻿using System.Windows;

namespace GraphicsBasics3D
{
   /// <summary>
   /// Interaction logic for Coordinate3D.xaml
   /// </summary>
   public partial class Coordinate3D : Window
   {
      public Coordinate3D()
      {
         InitializeComponent();
      }
   }
}

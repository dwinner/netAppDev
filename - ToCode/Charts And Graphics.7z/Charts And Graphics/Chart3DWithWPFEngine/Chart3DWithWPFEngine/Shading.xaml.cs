﻿using System.Windows;

namespace Chart3DWithWPFEngine
{
   /// <summary>
   /// Interaction logic for Shading.xaml
   /// </summary>
   public partial class Shading : Window
   {
      public Shading()
      {
         InitializeComponent();
      }
   }
}

﻿using System.Windows;

namespace Transformation3D
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {
   }
}

﻿namespace BookServiceClientApp
{
    public class Addresses
    {
        public const string BaseAddress = "http://localhost:5000/";
        public const string BooksApi = "api/BookChapters/";
    }
}

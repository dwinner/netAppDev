﻿using System.Windows.Controls;

namespace BooksDemo.Controls
{
  public class UIControlInfo
  {
    public string Title { get; set; }
    public UserControl Content { get; set; }
  }
}

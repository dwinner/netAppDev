﻿namespace ServiceControlWPF
{
  public enum ButtonState
  {
    Start,
    Stop,
    Pause,
    Continue
  }
}

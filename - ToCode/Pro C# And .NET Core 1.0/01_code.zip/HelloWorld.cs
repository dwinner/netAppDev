using static System.Console;

class Program
{
  static void Main()
  {
    WriteLine("Hello, World!");
  }
}
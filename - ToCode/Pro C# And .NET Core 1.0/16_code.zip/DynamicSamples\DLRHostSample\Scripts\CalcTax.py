﻿def CalcTax(amount):
   return amount*1.2
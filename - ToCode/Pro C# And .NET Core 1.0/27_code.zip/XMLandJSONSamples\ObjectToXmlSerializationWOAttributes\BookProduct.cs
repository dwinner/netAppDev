﻿namespace ObjectToXmlSerializationSample
{
    public class BookProduct : Product
    {
        public string ISBN { get; set; }

    }

}

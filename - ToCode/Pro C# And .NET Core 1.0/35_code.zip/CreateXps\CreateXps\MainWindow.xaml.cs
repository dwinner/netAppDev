﻿using System.Windows.Navigation;

namespace CreateXps
{
    /// <summary>
    /// Interaction logic for MenuPlannerWindow.xaml
    /// </summary>
    public partial class MainWindow : NavigationWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}

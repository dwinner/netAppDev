﻿using System;

namespace CreateXps
{
    public class MenuEntry
    {
        public DateTime Day { get; set; }
        public string Menu { get; set; }
        public decimal Price { get; set; }
    }
}
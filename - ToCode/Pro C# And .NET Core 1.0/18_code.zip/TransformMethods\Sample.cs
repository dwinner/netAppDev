﻿
namespace TransformMethods
{
    class Sample
    {
        public void foo()
        {
        }

        public void bar()
        {
        }
        
        private void fooBar()
        {
        }
    }
}

﻿using System.Xml.Linq;

namespace UnitTestingSamplesCore
{
    public interface IChampionsLoader
    {
        XElement LoadChampions();
    }
}

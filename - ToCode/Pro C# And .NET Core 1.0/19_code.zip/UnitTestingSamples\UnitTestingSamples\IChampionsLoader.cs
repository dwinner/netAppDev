﻿using System.Xml.Linq;

namespace UnitTestingSamples
{
    public interface IChampionsLoader
    {
        XElement LoadChampions();
    }
}

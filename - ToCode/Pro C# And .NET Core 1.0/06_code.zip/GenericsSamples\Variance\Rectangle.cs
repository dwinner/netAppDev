﻿
namespace Wrox.ProCSharp.Generics
{
  public class Rectangle : Shape
  {
  }
}

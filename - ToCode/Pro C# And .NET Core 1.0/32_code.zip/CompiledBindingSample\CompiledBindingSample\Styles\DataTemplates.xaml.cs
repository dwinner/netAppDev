﻿namespace CompiledBindingSample.Styles
{
    public sealed partial class DataTemplates
    {
        public DataTemplates()
        {
            this.InitializeComponent();
        }
    }
}

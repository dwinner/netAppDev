﻿using System;

namespace DataBindingSamples.Events
{
    public class BookInfoEvent : EventArgs
    {
        public int BookId { get; set; }
    }
}

# Readme - Code Samples for Chapter 40, ASP.NET Core

This chapter contains this sample:

* WebSampleApp

Building this sample starts with an empty ASP.NET Core Web project, and adds many features of ASP.NET Core.

The current version of this sample is built with .NET Core RC2. When RTM is available, the sample code will be updated.

﻿using System;

namespace EnumSample
{
    public enum Color : short
    {
        Red = 1,
        Green = 2,
        Blue = 3
    }
}
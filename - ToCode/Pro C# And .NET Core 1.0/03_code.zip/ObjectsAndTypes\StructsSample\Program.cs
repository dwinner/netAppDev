﻿using static System.Console;

namespace StructsSample
{
    class Program
    {
        static void Main()
        {
            var point = new Dimensions();
            point.Length = 3;
            point.Width = 6;

            ReadLine();
        }
    }
}

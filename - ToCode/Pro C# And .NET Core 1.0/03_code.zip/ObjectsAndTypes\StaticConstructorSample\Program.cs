﻿using static System.Console;

namespace StaticConstructorSample
{
    class Program
    {
        static void Main()
        {
            WriteLine($"User-preferences: BackColor is: {UserPreferences.BackColor}");

        }
    }
}
